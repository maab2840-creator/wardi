plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.wardi.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.hima.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 5
        versionName = "2.3"
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("hima.jks")
            storePassword = "hima1234"
            keyAlias = "hima"
            keyPassword = "hima1234"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
