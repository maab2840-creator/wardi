package com.wardi.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

object Scheduler {
    fun scheduleAll(ctx: Context) {
        val s = Store(ctx)
        for (k in Sections.keys) schedule(ctx, k, s.getTime(k))
    }

    fun schedule(ctx: Context, key: String, minutes: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, minutes / 60)
        cal.set(Calendar.MINUTE, minutes % 60)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        val i = Intent(ctx, AlarmReceiver::class.java).putExtra("key", key)
        val pi = PendingIntent.getBroadcast(
            ctx, Sections.keys.indexOf(key), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val key = intent.getStringExtra("key") ?: return
        val s = Store(ctx)
        Scheduler.schedule(ctx, key, s.getTime(key))
        if (s.getAdhkar(key).isNotEmpty() && !s.isDone(key)) {
            Notif.show(
                ctx, 100 + Sections.keys.indexOf(key),
                "حان وقت ${Sections.title(key)} ${Sections.emoji(key)}", key
            )
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Scheduler.scheduleAll(ctx)
    }
}
