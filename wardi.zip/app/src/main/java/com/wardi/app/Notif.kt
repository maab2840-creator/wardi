package com.wardi.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build

object Notif {
    private const val CH_SIMPLE = "hima_simple"

    private fun nm(ctx: Context) = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun canPost(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun channelId(key: String, ver: Int) = "w_${key}_$ver"

    /** قناة مستقلة لكل ورد؛ صوت القناة لا يتغير بعد إنشائها، لذلك نُنشئ قناة جديدة عند تغيير الصوت. */
    private fun ensureChannel(ctx: Context, s: Store, key: String): String {
        val id = channelId(key, s.chanVer(key))
        val m = nm(ctx)
        if (m.getNotificationChannel(id) == null) {
            val ch = NotificationChannel(id, "تنبيه ${Sections.title(key)}", NotificationManager.IMPORTANCE_HIGH)
            if (s.soundOn(key)) {
                val saved = s.soundUri(key)
                val uri: Uri = if (saved.isEmpty()) {
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                } else {
                    Uri.parse(saved)
                }
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                ch.setSound(uri, attrs)
                ch.enableVibration(true)
            } else {
                ch.setSound(null, null)
                ch.enableVibration(false)
            }
            m.createNotificationChannel(ch)
        }
        return id
    }

    /** يُستدعى عند تغيير إعدادات الصوت: نحذف القناة القديمة ونرفع الإصدار. */
    fun bump(ctx: Context, s: Store, key: String) {
        nm(ctx).deleteNotificationChannel(channelId(key, s.chanVer(key)))
        s.bumpChan(key)
    }

    fun wirdAlert(ctx: Context, key: String) {
        if (!canPost(ctx)) return
        val s = Store(ctx)
        val id = ensureChannel(ctx, s, key)
        val i = Intent(ctx, WirdActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra("key", key)
        val idx = Sections.keys.indexOf(key)
        val pi = PendingIntent.getActivity(
            ctx, 300 + idx, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, id)
            .setContentTitle(Sections.alertTitle(key))
            .setContentText(Sections.alertBody(key))
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setCategory(Notification.CATEGORY_REMINDER)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm(ctx).notify(100 + idx, n)
    }

    /** إشعار هادئ بلا صوت (مثل «وردك بانتظارك أولًا»). */
    fun simple(ctx: Context, id: Int, text: String, key: String? = null) {
        if (!canPost(ctx)) return
        val m = nm(ctx)
        m.createNotificationChannel(NotificationChannel(CH_SIMPLE, "حِمى", NotificationManager.IMPORTANCE_LOW))
        val i = Intent(ctx, WirdActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (key != null) i.putExtra("key", key)
        val pi = PendingIntent.getActivity(
            ctx, id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, CH_SIMPLE)
            .setContentTitle("حِمى")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        m.notify(id, n)
    }
}
