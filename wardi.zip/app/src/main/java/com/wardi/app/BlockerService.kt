package com.wardi.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class BlockerService : AccessibilityService() {
    private var last = 0L

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        val s = Store(this)
        if (!s.blockingEnabled) return
        if (pkg !in s.blockedApps()) return
        if (s.pendingSections().isEmpty()) return
        val now = System.currentTimeMillis()
        if (now - last < 1500) return
        last = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        val i = Intent(this, WirdActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("blocked", true)
        startActivity(i)
        Notif.show(this, 200, "أكملي وردك أولًا 🤍")
    }

    override fun onInterrupt() {}
}
