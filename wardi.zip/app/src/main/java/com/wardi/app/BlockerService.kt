package com.wardi.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout

class BlockerService : AccessibilityService() {
    private var overlay: View? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        Store(this).markConnected()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        val s = Store(this)
        val blocked = pkg in s.blockedApps()
        val pending = s.pendingSections()
        val reason = when {
            !s.blockingEnabled -> "الحجب متوقف من الإعدادات"
            !blocked -> "التطبيق ليس في قائمة الحجب"
            pending.isEmpty() -> "لا يوجد ورد مطلوب الآن"
            else -> "تم الحجب"
        }
        s.recordEvent(pkg, reason)
        if (s.blockingEnabled && blocked && pending.isNotEmpty()) {
            showOverlay(s, pending.first())
        } else {
            hideOverlay()
        }
    }

    private fun startWird() {
        val i = Intent(this, WirdActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("blocked", true)
        startActivity(i)
    }

    private fun buildOverlay(key: String): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(C.BG)
        root.setPadding(dp(24), dp(24), dp(24), dp(24))
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.addView(img(R.drawable.art_shield, 190, 210))
        root.addView(tv("هذا التطبيق محظور مؤقتًا 🔒", 24f, C.TEXT, true, true, true))
        root.addView(tv("أكمل وردك في حِمى للمتابعة.", 16f, C.MUTED, false, true))
        root.addView(btn("ابدأ الورد", C.PRIMARY) {
            hideOverlay()
            startWird()
        })
        root.addView(btn("العودة إلى الشاشة الرئيسية", C.CARD, C.PRIMARY_DARK) {
            hideOverlay()
            performGlobalAction(GLOBAL_ACTION_HOME)
        })
        return root
    }

    private fun showOverlay(s: Store, key: String) {
        if (overlay != null) return
        C.setTheme(s.theme)
        val v = buildOverlay(key)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.OPAQUE
        )
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(v, lp)
            overlay = v
            Notif.simple(this, 200, "وردك بانتظارك أولًا 🤍", key)
        } catch (ex: Exception) {
            s.recordEvent("-", "تعذّر عرض شاشة الحجب: ${ex.javaClass.simpleName}")
            performGlobalAction(GLOBAL_ACTION_HOME)
            startWird()
        }
    }

    private fun hideOverlay() {
        val v = overlay ?: return
        overlay = null
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (ex: Exception) {
        }
    }

    override fun onInterrupt() {
        hideOverlay()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        hideOverlay()
        return super.onUnbind(intent)
    }
}
