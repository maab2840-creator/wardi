package com.wardi.app

import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView

class WirdActivity : Activity() {
    private lateinit var store: Store
    private var key = ""
    private var list: List<Dhikr> = emptyList()
    private var idx = 0
    private var cnt = 0
    private var fromBlock = false

    private lateinit var tvIndex: TextView
    private lateinit var tvDhikr: TextView
    private lateinit var tvCount: TextView
    private lateinit var vDone: TextView
    private lateinit var vLeft: TextView
    private lateinit var vPct: TextView
    private lateinit var bar: ProgressBar
    private lateinit var beads: BeadsView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        C.setTheme(store.theme)
        styleBars()
        load(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        load(intent)
    }

    private fun load(i: Intent) {
        fromBlock = i.getBooleanExtra("blocked", false)
        val k = i.getStringExtra("key") ?: store.dueSections().firstOrNull()
        if (k == null) {
            message("لا يوجد ورد مطلوب الآن 🤍", "إغلاق") { leave() }
            return
        }
        val l = store.getAdhkar(k)
        if (l.isEmpty()) {
            message("لا توجد أذكار في هذا القسم بعد. أضفها من الشاشة الرئيسية.", "إغلاق") { leave() }
            return
        }
        key = k
        list = l
        val (pi, pc) = store.progress(k)
        idx = if (pi < l.size) pi else 0
        cnt = pc
        buildCounter()
    }

    private fun leave() {
        if (fromBlock) {
            startActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (fromBlock) leave() else super.onBackPressed()
    }

    private fun screen(content: LinearLayout.() -> Unit) {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(18), dp(20), dp(18), dp(24))
        col.content()
        val sv = ScrollView(this)
        sv.setBackgroundColor(C.BG)
        sv.layoutDirection = View.LAYOUT_DIRECTION_RTL
        sv.addView(col)
        setContentView(sv)
    }

    private fun message(text: String, btnText: String, action: () -> Unit) {
        screen {
            addView(img(R.drawable.art_shield, 180, 210))
            addView(tv(text, 24f, C.TEXT, true, true, true))
            addView(btn(btnText, C.PRIMARY) { action() })
        }
    }

    private fun statCol(label: String, value: TextView): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        c.addView(tv(label, 13f, C.MUTED, false, true))
        c.addView(value)
        return c
    }

    private fun statValue(): TextView = tv("", 22f, C.TEXT, true, true, true)

    private fun buildCounter() {
        tvIndex = TextView(this)
        tvDhikr = tv("", 26f, C.PRIMARY_DARK, true, true, true)
        tvCount = tv("", 30f, C.TEXT, true, true, true)
        vDone = statValue()
        vLeft = statValue()
        vPct = statValue()
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100
        bar.progressTintList = ColorStateList.valueOf(C.PRIMARY)
        bar.progressBackgroundTintList = ColorStateList.valueOf(C.BEAD_OFF)
        beads = BeadsView(this)

        screen {
            addView(tv("${Sections.emoji(key)}  ${Sections.title(key)}", 22f, C.PRIMARY_DARK, true, true, true))

            val mainCard = card()
            mainCard.gravity = Gravity.CENTER_HORIZONTAL
            tvIndex.textSize = 13f
            tvIndex.setTextColor(C.MUTED)
            tvIndex.gravity = Gravity.CENTER
            tvIndex.setPadding(dp(16), dp(6), dp(16), dp(6))
            tvIndex.background = rounded(C.SOFT, dp(16).toFloat())
            val ilp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            ilp.gravity = Gravity.CENTER_HORIZONTAL
            tvIndex.layoutParams = ilp
            mainCard.addView(tvIndex)
            mainCard.addView(tvDhikr)
            mainCard.addView(tv("العدد", 14f, C.MUTED, false, true))
            mainCard.addView(tvCount)

            val frame = FrameLayout(this@WirdActivity)
            val flp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(300))
            flp.topMargin = dp(8)
            frame.layoutParams = flp
            val blp = FrameLayout.LayoutParams(dp(250), dp(300))
            blp.gravity = Gravity.CENTER_HORIZONTAL
            beads.layoutParams = blp
            frame.addView(beads)
            for (side in 0..1) {
                val sp = ImageView(this@WirdActivity)
                sp.setImageResource(R.drawable.deco_sprig)
                val slp = FrameLayout.LayoutParams(dp(70), dp(70))
                slp.gravity = Gravity.BOTTOM or (if (side == 0) Gravity.START else Gravity.END)
                sp.layoutParams = slp
                sp.alpha = 0.9f
                if (side == 1) sp.scaleX = -1f
                frame.addView(sp)
            }
            mainCard.addView(frame)
            addView(mainCard)

            val statsCard = card()
            val row = LinearLayout(this@WirdActivity)
            row.orientation = LinearLayout.HORIZONTAL
            row.addView(statCol("المكتمل", vDone))
            row.addView(statCol("التقدم", vPct))
            row.addView(statCol("المتبقي", vLeft))
            statsCard.addView(row)
            val blpBar = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8))
            blpBar.topMargin = dp(12)
            bar.layoutParams = blpBar
            statsCard.addView(bar)
            addView(statsCard)
        }

        beads.setOnClickListener { v ->
            v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(50).withEndAction {
                v.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
            }.start()
            tap()
        }
        update()
    }

    private fun update() {
        val d = list[idx]
        val total = list.sumOf { it.count }
        val done = list.take(idx).sumOf { it.count } + cnt
        val percent = if (total == 0) 0 else done * 100 / total
        tvIndex.text = "ذكر رقم ${idx + 1} من ${list.size}"
        tvDhikr.text = d.text
        tvCount.text = "\u200E$cnt / ${d.count}\u200E"
        beads.fraction = cnt.toFloat() / d.count
        beads.invalidate()
        vDone.text = "$cnt"
        vLeft.text = "${d.count - cnt}"
        vPct.text = "$percent%"
        bar.progress = percent
    }

    private fun tap() {
        cnt++
        if (cnt >= list[idx].count) {
            idx++
            cnt = 0
        }
        if (idx >= list.size) {
            finishWird()
            return
        }
        store.setProgress(key, idx, cnt)
        update()
    }

    private fun finishWird() {
        store.setDone(key)
        store.clearProgress(key)
        store.recordDayIfComplete()
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancelAll()
        val next = store.dueSections().firstOrNull()
        val all = store.allDoneToday()
        val streak = store.streak()
        val milestone = all && streak in Cheer.MILESTONES && store.celebrated() != store.today()
        if (milestone) store.setCelebrated()
        val counts = store.doneCount()

        screen {
            addView(img(R.drawable.art_shield, 170, 190))
            addView(tv("ما شاء الله 🤍", 32f, C.TEXT, true, true, true))
            addView(tv("تم إكمال وردك", 30f, C.TEXT, true, true, true))

            if (milestone) {
                addView(tv("🎉 ${Cheer.milestoneMessage(streak)}", 18f, C.PRIMARY_DARK, true, true, true))
            }

            if (all && streak > 0) {
                addView(pill("flame", Cheer.streakLine(streak)))
                val dots = LinearLayout(this@WirdActivity)
                dots.orientation = LinearLayout.HORIZONTAL
                dots.gravity = Gravity.CENTER
                val dlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                dlp.topMargin = dp(14)
                dlp.gravity = Gravity.CENTER_HORIZONTAL
                dots.layoutParams = dlp
                for (on in store.weekDots()) {
                    val dot = FrameLayout(this@WirdActivity)
                    dot.background = oval(if (on) C.PRIMARY else C.BEAD_OFF)
                    dot.setPadding(dp(5), dp(5), dp(5), dp(5))
                    if (on) dot.addView(IconView(this@WirdActivity, "check", C.ON_PRIMARY))
                    val lp = LinearLayout.LayoutParams(dp(30), dp(30))
                    lp.marginStart = dp(4)
                    lp.marginEnd = dp(4)
                    dot.layoutParams = lp
                    dots.addView(dot)
                }
                addView(dots)
                val nm = Cheer.nextMilestone(streak)
                if (nm != null) {
                    addView(tv("الإنجاز القادم: ${Cheer.milestoneName(nm)} (بقي ${Cheer.daysCount(nm - streak)})", 14f, C.MUTED, false, true))
                } else {
                    addView(tv("ثباتك جميل، بارك الله في وردك.", 14f, C.MUTED, false, true))
                }
            } else {
                addView(tv("أكملت ${counts.first} من ${counts.second} أورد اليوم", 15f, C.MUTED, false, true))
                if (next != null) addView(tv("بقي: ${Sections.title(next)}", 15f, C.MUTED, false, true))
            }

            addView(btn("تم بحمد الله", C.PRIMARY) {
                if (next != null) {
                    load(Intent(this@WirdActivity, WirdActivity::class.java).putExtra("key", next).putExtra("blocked", fromBlock))
                } else {
                    leave()
                }
            })
        }
    }
}
