package com.wardi.app

import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView

class WirdActivity : Activity() {
    private lateinit var store: Store
    private var key = ""
    private var list: List<Dhikr> = emptyList()
    private var idx = 0
    private var cnt = 0
    private var fromBlock = false

    private lateinit var tvIndex: TextView
    private lateinit var tvDhikr: TextView
    private lateinit var tvCount: TextView
    private lateinit var tvStats: TextView
    private lateinit var tvPercent: TextView
    private lateinit var bar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        load(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        load(intent)
    }

    private fun load(i: Intent) {
        fromBlock = i.getBooleanExtra("blocked", false)
        val k = i.getStringExtra("key") ?: store.pendingSections().firstOrNull()
        if (k == null) {
            message("لا يوجد ورد مطلوب الآن 🤍", "إغلاق", null) { leave() }
            return
        }
        val l = store.getAdhkar(k)
        if (l.isEmpty()) {
            message("لا توجد أذكار في هذا القسم بعد. أضيفيها من الشاشة الرئيسية.", "إغلاق", null) { leave() }
            return
        }
        key = k
        list = l
        val (pi, pc) = store.progress(k)
        idx = if (pi < l.size) pi else 0
        cnt = pc
        buildCounter()
    }

    private fun leave() {
        if (fromBlock) {
            startActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (fromBlock) leave() else super.onBackPressed()
    }

    private fun message(text: String, btnText: String, extra: String?, action: () -> Unit) {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(C.BG)
        root.setPadding(dp(24), dp(24), dp(24), dp(24))
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.addView(tv(text, 30f, C.PRIMARY_DARK, true, true))
        if (extra != null) root.addView(tv(extra, 16f, C.MUTED, false, true))
        root.addView(btn(btnText, C.GREEN) { action() })
        setContentView(root)
    }

    private fun buildCounter() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setBackgroundColor(C.BG)
        root.setPadding(dp(20), dp(24), dp(20), dp(28))
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL

        root.addView(tv("${Sections.emoji(key)}  ${Sections.title(key)}", 24f, C.PRIMARY_DARK, true, true))
        tvIndex = tv("", 15f, C.MUTED, false, true)
        root.addView(tvIndex)

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100
        bar.progressTintList = ColorStateList.valueOf(C.PRIMARY)
        val blp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(10))
        blp.topMargin = dp(12)
        root.addView(bar, blp)
        tvPercent = tv("", 14f, C.MUTED, false, true)
        root.addView(tvPercent)

        val sv = ScrollView(this)
        sv.isFillViewport = true
        tvDhikr = tv("", 28f, C.TEXT, true, true)
        tvDhikr.setLineSpacing(0f, 1.3f)
        sv.addView(tvDhikr, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        tvCount = tv("", 40f, C.PRIMARY_DARK, true, true)
        root.addView(tvCount)
        tvStats = tv("", 14f, C.MUTED, false, true)
        root.addView(tvStats)

        val circle = TextView(this)
        circle.text = "سبّح"
        circle.textSize = 26f
        circle.setTextColor(Color.WHITE)
        circle.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(C.PRIMARY)
        circle.background = bg
        circle.setOnClickListener { tap(it) }
        val clp = LinearLayout.LayoutParams(dp(190), dp(190))
        clp.gravity = Gravity.CENTER_HORIZONTAL
        clp.topMargin = dp(16)
        root.addView(circle, clp)

        setContentView(root)
        update()
    }

    private fun update() {
        val d = list[idx]
        val total = list.sumOf { it.count }
        val done = list.take(idx).sumOf { it.count } + cnt
        val percent = if (total == 0) 0 else done * 100 / total
        tvIndex.text = "الذكر ${idx + 1} من ${list.size}"
        tvDhikr.text = d.text
        tvCount.text = "$cnt / ${d.count}"
        bar.progress = percent
        tvPercent.text = "تقدّم الورد: $percent%"
        tvStats.text = "المكتمل: $cnt  •  المتبقي: ${d.count - cnt}\nإجمالي الورد: $done / $total"
    }

    private fun tap(v: View) {
        v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        cnt++
        if (cnt >= list[idx].count) {
            idx++
            cnt = 0
        }
        if (idx >= list.size) {
            finishWird()
            return
        }
        store.setProgress(key, idx, cnt)
        update()
    }

    private fun finishWird() {
        store.setDone(key)
        store.clearProgress(key)
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancelAll()
        val next = store.pendingSections().firstOrNull()
        val extra = if (next != null) "بقي عليكِ: ${Sections.title(next)}" else null
        message("ما شاء الله، تم إكمال الورد 🤍", "تم بحمد الله", extra) {
            if (next != null) {
                load(Intent(this, WirdActivity::class.java).putExtra("key", next).putExtra("blocked", fromBlock))
            } else {
                leave()
            }
        }
    }
}
