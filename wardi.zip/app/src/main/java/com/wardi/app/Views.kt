package com.wardi.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/** مسبحة دائرية: الحبات تضيء كلما تقدّم العدّ، والضغط على الدائرة يزيد العداد. */
class BeadsView(ctx: Context) : View(ctx) {
    var fraction = 0f
    var centerText = "اضغط هنا"
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val pad = context.dp(18).toFloat()
        val ringR = w / 2f - pad
        val cx = w / 2f
        val cy = ringR + pad * 0.6f
        val n = 26
        val beadR = ringR * 0.075f
        val lit = (fraction * n).toInt()
        for (i in 0 until n) {
            val a = -Math.PI / 2 + 2 * Math.PI * i / n
            paint.color = if (i < lit) C.BEAD else C.BEAD_OFF
            c.drawCircle(
                (cx + ringR * Math.cos(a)).toFloat(),
                (cy + ringR * Math.sin(a)).toFloat(),
                beadR, paint
            )
        }
        paint.color = C.BEAD
        val ty = cy + ringR + beadR
        val path = Path()
        path.moveTo(cx - context.dp(5), ty)
        path.lineTo(cx + context.dp(5), ty)
        path.lineTo(cx + context.dp(10), ty + context.dp(32))
        path.lineTo(cx - context.dp(10), ty + context.dp(32))
        path.close()
        c.drawPath(path, paint)
        paint.color = C.SOFT
        c.drawCircle(cx, cy, ringR * 0.7f, paint)
        tp.color = C.PRIMARY_DARK
        tp.textAlign = Paint.Align.CENTER
        tp.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        tp.textSize = context.dp(22).toFloat()
        c.drawText(centerText, cx, cy + tp.textSize / 3f, tp)
    }
}

/** أيقونة خطية مرسومة برمجيًا (24×24) بنفس الأسلوب في كل التطبيق. */
class IconView(ctx: Context, private val name: String, var iconColor: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = 1.8f
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val s = minOf(width, height).toFloat() / 24f
        c.save()
        c.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
        c.scale(s, s)
        p.color = iconColor
        Icons.draw(c, name, p)
        c.restore()
    }
}

object Icons {
    private fun rays(c: Canvas, p: Paint, cx: Float, cy: Float, r1: Float, r2: Float, angles: List<Int>) {
        for (a in angles) {
            val t = Math.toRadians(a.toDouble())
            c.drawLine(
                (cx + r1 * cos(t)).toFloat(), (cy + r1 * sin(t)).toFloat(),
                (cx + r2 * cos(t)).toFloat(), (cy + r2 * sin(t)).toFloat(), p
            )
        }
    }

    fun draw(c: Canvas, name: String, p: Paint) {
        when (name) {
            "sun" -> {
                c.drawCircle(12f, 12f, 4f, p)
                rays(c, p, 12f, 12f, 6.8f, 9.4f, listOf(0, 45, 90, 135, 180, 225, 270, 315))
            }
            "sunrise" -> {
                c.drawArc(RectF(8f, 11f, 16f, 19f), 180f, 180f, false, p)
                c.drawLine(3f, 15f, 21f, 15f, p)
                c.drawLine(7f, 19f, 17f, 19f, p)
                rays(c, p, 12f, 15f, 6.5f, 9.2f, listOf(225, 270, 315))
            }
            "sunset" -> {
                c.drawArc(RectF(8f, 10f, 16f, 18f), 180f, 180f, false, p)
                c.drawLine(3f, 14f, 21f, 14f, p)
                c.drawLine(7f, 17.5f, 17f, 17.5f, p)
                c.drawLine(10f, 21f, 14f, 21f, p)
                rays(c, p, 12f, 14f, 6.5f, 9f, listOf(225, 270, 315))
            }
            "moon" -> {
                val a = Path()
                a.addCircle(12f, 12f, 8f, Path.Direction.CW)
                val b = Path()
                b.addCircle(17f, 8.5f, 6.5f, Path.Direction.CW)
                a.op(b, Path.Op.DIFFERENCE)
                c.drawPath(a, p)
            }
            "home" -> {
                val h = Path()
                h.moveTo(3f, 11.5f); h.lineTo(12f, 4f); h.lineTo(21f, 11.5f)
                h.moveTo(5.5f, 10f); h.lineTo(5.5f, 20f); h.lineTo(18.5f, 20f); h.lineTo(18.5f, 10f)
                h.moveTo(10f, 20f); h.lineTo(10f, 14.5f); h.lineTo(14f, 14.5f); h.lineTo(14f, 20f)
                c.drawPath(h, p)
            }
            "book" -> {
                val b = Path()
                b.moveTo(12f, 7f)
                b.cubicTo(9.5f, 5.3f, 6f, 5f, 3f, 6f)
                b.lineTo(3f, 18.5f)
                b.cubicTo(6f, 17.5f, 9.5f, 17.8f, 12f, 19.5f)
                b.cubicTo(14.5f, 17.8f, 18f, 17.5f, 21f, 18.5f)
                b.lineTo(21f, 6f)
                b.cubicTo(18f, 5f, 14.5f, 5.3f, 12f, 7f)
                b.moveTo(12f, 7f); b.lineTo(12f, 19.5f)
                c.drawPath(b, p)
            }
            "apps" -> {
                c.drawRoundRect(RectF(4f, 4f, 10f, 10f), 1.6f, 1.6f, p)
                c.drawRoundRect(RectF(14f, 4f, 20f, 10f), 1.6f, 1.6f, p)
                c.drawRoundRect(RectF(4f, 14f, 10f, 20f), 1.6f, 1.6f, p)
                c.drawRoundRect(RectF(14f, 14f, 20f, 20f), 1.6f, 1.6f, p)
            }
            "settings" -> {
                c.drawCircle(12f, 12f, 3f, p)
                c.drawCircle(12f, 12f, 7f, p)
                rays(c, p, 12f, 12f, 7f, 9.6f, listOf(0, 45, 90, 135, 180, 225, 270, 315))
            }
            "lock" -> {
                c.drawRoundRect(RectF(5f, 11f, 19f, 20.5f), 2.5f, 2.5f, p)
                val s = Path()
                s.moveTo(8f, 11f); s.lineTo(8f, 8f)
                s.arcTo(RectF(8f, 4f, 16f, 12f), 180f, 180f, false)
                s.lineTo(16f, 11f)
                c.drawPath(s, p)
                c.drawCircle(12f, 15.7f, 1f, p)
            }
            "flame" -> {
                val f = Path()
                f.moveTo(12f, 3f)
                f.cubicTo(15f, 7f, 18f, 9f, 18f, 14f)
                f.cubicTo(18f, 18f, 15f, 21f, 12f, 21f)
                f.cubicTo(9f, 21f, 6f, 18f, 6f, 14f)
                f.cubicTo(6f, 11f, 8f, 9.5f, 9f, 8f)
                f.cubicTo(10f, 10f, 10.5f, 10.5f, 11f, 10.5f)
                f.cubicTo(11.5f, 8f, 12f, 5.5f, 12f, 3f)
                c.drawPath(f, p)
            }
            "check" -> {
                val k = Path()
                k.moveTo(5f, 12.5f); k.lineTo(10f, 17.5f); k.lineTo(19f, 7f)
                c.drawPath(k, p)
            }
            "calendar" -> {
                c.drawRoundRect(RectF(4f, 5f, 20f, 20f), 2.5f, 2.5f, p)
                c.drawLine(4f, 10f, 20f, 10f, p)
                c.drawLine(8f, 3f, 8f, 7f, p)
                c.drawLine(16f, 3f, 16f, 7f, p)
            }
            "bell" -> {
                val b = Path()
                b.moveTo(6f, 17f)
                b.cubicTo(6f, 17f, 7f, 15f, 7f, 11f)
                b.cubicTo(7f, 7f, 9.5f, 5f, 12f, 5f)
                b.cubicTo(14.5f, 5f, 17f, 7f, 17f, 11f)
                b.cubicTo(17f, 15f, 18f, 17f, 18f, 17f)
                b.close()
                c.drawPath(b, p)
                c.drawArc(RectF(10f, 17.5f, 14f, 21.5f), 0f, 180f, false, p)
            }
            "shield" -> {
                val s = Path()
                s.moveTo(12f, 3f); s.lineTo(19f, 6f); s.lineTo(19f, 12f)
                s.cubicTo(19f, 16.5f, 16f, 19.5f, 12f, 21f)
                s.cubicTo(8f, 19.5f, 5f, 16.5f, 5f, 12f)
                s.lineTo(5f, 6f); s.close()
                c.drawPath(s, p)
            }
            "plus" -> {
                c.drawLine(12f, 5f, 12f, 19f, p)
                c.drawLine(5f, 12f, 19f, 12f, p)
            }
            else -> c.drawCircle(12f, 12f, 6f, p)
        }
    }
}
