package com.wardi.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.view.View

/** مسبحة دائرية: الحبات تضيء كلما تقدّم العدّ، والضغط على الدائرة يزيد العداد. */
class BeadsView(ctx: Context) : View(ctx) {
    var fraction = 0f
    var centerText = "اضغط هنا"
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val pad = context.dp(18).toFloat()
        val ringR = w / 2f - pad
        val cx = w / 2f
        val cy = ringR + pad * 0.6f
        val n = 26
        val beadR = ringR * 0.075f
        val lit = (fraction * n).toInt()
        for (i in 0 until n) {
            val a = -Math.PI / 2 + 2 * Math.PI * i / n
            paint.color = if (i < lit) C.BEAD else C.BEAD_OFF
            c.drawCircle(
                (cx + ringR * Math.cos(a)).toFloat(),
                (cy + ringR * Math.sin(a)).toFloat(),
                beadR, paint
            )
        }
        // الشرّابة أسفل المسبحة
        paint.color = C.BEAD
        val ty = cy + ringR + beadR
        val path = Path()
        path.moveTo(cx - context.dp(5), ty)
        path.lineTo(cx + context.dp(5), ty)
        path.lineTo(cx + context.dp(10), ty + context.dp(32))
        path.lineTo(cx - context.dp(10), ty + context.dp(32))
        path.close()
        c.drawPath(path, paint)
        // قرص الوسط
        paint.color = C.SOFT
        c.drawCircle(cx, cy, ringR * 0.7f, paint)
        tp.color = C.PRIMARY_DARK
        tp.textAlign = Paint.Align.CENTER
        tp.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        tp.textSize = context.dp(22).toFloat()
        c.drawText(centerText, cx, cy + tp.textSize / 3f, tp)
    }
}
