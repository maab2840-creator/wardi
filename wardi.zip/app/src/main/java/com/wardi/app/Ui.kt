package com.wardi.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

object C {
    val BG = Color.parseColor("#F6F1EA")
    val PRIMARY = Color.parseColor("#2E7D6B")
    val PRIMARY_DARK = Color.parseColor("#1F5A4C")
    val GREEN = Color.parseColor("#2E7D32")
    val SOFT = Color.parseColor("#E3EFEA")
    val TEXT = Color.parseColor("#2B2B2B")
    val MUTED = Color.parseColor("#7A7A7A")
    val WARN = Color.parseColor("#C62828")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun rounded(color: Int, radius: Float): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

fun Context.tv(
    text: String,
    size: Float = 18f,
    color: Int = C.TEXT,
    bold: Boolean = false,
    center: Boolean = false
): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = size
    t.setTextColor(color)
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    if (center) t.gravity = Gravity.CENTER
    val lp = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
    lp.topMargin = dp(8)
    t.layoutParams = lp
    return t
}

fun Context.btn(
    text: String,
    bg: Int = C.PRIMARY,
    fg: Int = Color.WHITE,
    onClick: () -> Unit
): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = 18f
    t.setTextColor(fg)
    t.gravity = Gravity.CENTER
    t.setTypeface(t.typeface, Typeface.BOLD)
    t.setPadding(dp(16), dp(16), dp(16), dp(16))
    t.background = rounded(bg, dp(16).toFloat())
    val lp = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
    lp.topMargin = dp(12)
    t.layoutParams = lp
    t.setOnClickListener { onClick() }
    return t
}

fun Context.card(): LinearLayout {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.setPadding(dp(16), dp(14), dp(16), dp(14))
    c.background = rounded(Color.WHITE, dp(16).toFloat())
    val lp = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
    lp.topMargin = dp(12)
    c.layoutParams = lp
    return c
}
