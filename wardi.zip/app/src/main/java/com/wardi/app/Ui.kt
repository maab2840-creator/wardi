package com.wardi.app

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

object C {
    var themeIndex = 0
    var BG = 0
    var CARD = 0
    var PRIMARY = 0
    var PRIMARY_DARK = 0
    var ON_PRIMARY = 0
    var TEXT = 0
    var MUTED = 0
    var SOFT = 0
    var BORDER = 0
    var GREEN = 0
    var WARN = 0
    var BEAD = 0
    var BEAD_OFF = 0
    var IC_BG = intArrayOf(0, 0, 0, 0)
    var IC_FG = intArrayOf(0, 0, 0, 0)

    val THEME_NAMES = listOf("أخضر", "أبيض", "أزرق", "بيج", "داكن")
    val isDark: Boolean get() = themeIndex == 4

    private fun c(s: String): Int = Color.parseColor(s)

    private fun pal(
        bg: String, card: String, pr: String, prd: String, on: String, tx: String, mu: String,
        soft: String, bd: String, green: String, warn: String, bead: String, beadOff: String
    ) {
        BG = c(bg); CARD = c(card); PRIMARY = c(pr); PRIMARY_DARK = c(prd); ON_PRIMARY = c(on)
        TEXT = c(tx); MUTED = c(mu); SOFT = c(soft); BORDER = c(bd); GREEN = c(green)
        WARN = c(warn); BEAD = c(bead); BEAD_OFF = c(beadOff)
    }

    fun setTheme(i: Int) {
        themeIndex = if (i in 0..4) i else 0
        when (themeIndex) {
            1 -> pal("#FFFFFF", "#F5F7F8", "#33606E", "#264A55", "#FFFFFF", "#1C2429", "#6C7880",
                "#E6EEF1", "#E3E8EB", "#33606E", "#B3402F", "#3F7482", "#D3E1E6")
            2 -> pal("#EAF0F8", "#FFFFFF", "#2F5D9E", "#234A80", "#FFFFFF", "#1B2433", "#66748A",
                "#DCE6F5", "#D5DFEE", "#2F5D9E", "#B3402F", "#3E6FB5", "#C9D8EE")
            3 -> pal("#F4EBDD", "#FCF8F1", "#7A5A3A", "#5E4429", "#FFFFFF", "#3A2A1C", "#8A7A6A",
                "#EADFCF", "#E5D8C5", "#6B7F4A", "#B3402F", "#8B6B45", "#D9CBB4")
            4 -> pal("#121614", "#1C2320", "#6CC39A", "#8FDDB8", "#0E1512", "#E8EEEA", "#93A39A",
                "#26332D", "#2B3832", "#6CC39A", "#FF8A80", "#6CC39A", "#33443B")
            else -> pal("#F1F5F0", "#FFFFFF", "#2F6B4F", "#245640", "#FFFFFF", "#1F2A24", "#6B7A72",
                "#DDEBE3", "#DCE6DF", "#2F6B4F", "#B3402F", "#3F7A5B", "#CFE0D6")
        }
        if (isDark) {
            IC_BG = intArrayOf(c("#3A2B1E"), c("#2F2740"), c("#1F2E4A"), c("#26382A"))
            IC_FG = intArrayOf(c("#F0B27A"), c("#C3A6E8"), c("#8FB2F0"), c("#A9D18E"))
        } else {
            IC_BG = intArrayOf(c("#FBE3CF"), c("#E7DAEF"), c("#DCE4F3"), c("#E4EAD6"))
            IC_FG = intArrayOf(c("#B5651D"), c("#6B4E9B"), c("#3F5F9B"), c("#4F6B3A"))
        }
    }

    init {
        setTheme(0)
    }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun rounded(color: Int, radius: Float): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = radius
    return g
}

fun oval(color: Int): GradientDrawable {
    val g = GradientDrawable()
    g.shape = GradientDrawable.OVAL
    g.setColor(color)
    return g
}

@Suppress("DEPRECATION")
fun Activity.styleBars() {
    window.statusBarColor = C.BG
    window.navigationBarColor = C.BG
    val d = window.decorView
    var f = d.systemUiVisibility
    f = if (C.isDark) {
        f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
    } else {
        f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
    }
    d.systemUiVisibility = f
}

fun Context.tv(
    text: String,
    size: Float = 18f,
    color: Int = C.TEXT,
    bold: Boolean = false,
    center: Boolean = false,
    serif: Boolean = false
): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = size
    t.setTextColor(color)
    if (serif) {
        t.typeface = Typeface.create(Typeface.SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL)
    } else if (bold) {
        t.setTypeface(t.typeface, Typeface.BOLD)
    }
    if (center) t.gravity = Gravity.CENTER
    val lp = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
    lp.topMargin = dp(8)
    t.layoutParams = lp
    return t
}

fun Context.btn(
    text: String,
    bg: Int = C.PRIMARY,
    fg: Int = C.ON_PRIMARY,
    onClick: () -> Unit
): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = 18f
    t.setTextColor(fg)
    t.gravity = Gravity.CENTER
    t.setTypeface(t.typeface, Typeface.BOLD)
    t.setPadding(dp(16), dp(16), dp(16), dp(16))
    t.background = rounded(bg, dp(28).toFloat())
    val lp = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
    lp.topMargin = dp(14)
    t.layoutParams = lp
    t.setOnClickListener { onClick() }
    return t
}

fun Context.card(): LinearLayout {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.setPadding(dp(16), dp(14), dp(16), dp(14))
    val bg = rounded(C.CARD, dp(22).toFloat())
    bg.setStroke(dp(1), C.BORDER)
    c.background = bg
    val lp = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
    lp.topMargin = dp(12)
    c.layoutParams = lp
    return c
}

fun Context.img(res: Int, w: Int, h: Int): ImageView {
    val v = ImageView(this)
    v.setImageResource(res)
    v.scaleType = ImageView.ScaleType.FIT_CENTER
    val lp = LinearLayout.LayoutParams(dp(w), dp(h))
    lp.gravity = Gravity.CENTER_HORIZONTAL
    lp.topMargin = dp(8)
    v.layoutParams = lp
    return v
}

/** أيقونة خطية بلا خلفية. */
fun Context.icon(name: String, color: Int, sizeDp: Int): IconView {
    val v = IconView(this, name, color)
    v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    return v
}

/** أيقونة خطية داخل دائرة ناعمة. */
fun Context.iconCircle(name: String, bg: Int, fg: Int, sizeDp: Int = 48): View {
    val f = FrameLayout(this)
    f.background = oval(bg)
    val pad = dp(sizeDp / 5)
    f.setPadding(pad, pad, pad, pad)
    f.addView(IconView(this, name, fg), FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    f.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    return f
}

/** كبسولة صغيرة فيها أيقونة ونص، تُستخدم لسلسلة الالتزام. */
fun Context.pill(iconName: String, text: String): LinearLayout {
    val p = LinearLayout(this)
    p.orientation = LinearLayout.HORIZONTAL
    p.gravity = Gravity.CENTER_VERTICAL
    p.setPadding(dp(16), dp(8), dp(18), dp(8))
    p.background = rounded(C.SOFT, dp(22).toFloat())
    val ic = IconView(this, iconName, C.PRIMARY)
    val ilp = LinearLayout.LayoutParams(dp(20), dp(20))
    ilp.marginEnd = dp(8)
    p.addView(ic, ilp)
    val t = TextView(this)
    t.text = text
    t.textSize = 15f
    t.setTextColor(C.PRIMARY_DARK)
    t.setTypeface(t.typeface, Typeface.BOLD)
    p.addView(t)
    val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    lp.gravity = Gravity.CENTER_HORIZONTAL
    lp.topMargin = dp(12)
    p.layoutParams = lp
    return p
}
