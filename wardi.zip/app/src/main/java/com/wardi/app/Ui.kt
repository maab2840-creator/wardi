package com.wardi.app

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

object C {
    var themeIndex = 0
    var BG = 0
    var CARD = 0
    var PRIMARY = 0
    var PRIMARY_DARK = 0
    var ON_PRIMARY = 0
    var TEXT = 0
    var MUTED = 0
    var SOFT = 0
    var BORDER = 0
    var GREEN = 0
    var WARN = 0
    var BEAD = 0
    var BEAD_OFF = 0
    var SEC = intArrayOf(0, 0, 0, 0)

    val THEME_NAMES = listOf("رمل وأخضر", "أزرق ليلي", "بنفسجي هادئ")

    fun setTheme(i: Int) {
        themeIndex = i
        when (i) {
            1 -> {
                BG = Color.parseColor("#0F1B2D"); CARD = Color.parseColor("#182840")
                PRIMARY = Color.parseColor("#E0B94F"); PRIMARY_DARK = Color.parseColor("#F2D888")
                ON_PRIMARY = Color.parseColor("#1A1A1A"); TEXT = Color.parseColor("#EAF0F8")
                MUTED = Color.parseColor("#9FB0C8"); SOFT = Color.parseColor("#24395A")
                BORDER = Color.parseColor("#263B5C"); GREEN = Color.parseColor("#7FC8A0")
                WARN = Color.parseColor("#FF8A80"); BEAD = Color.parseColor("#E0B94F")
                BEAD_OFF = Color.parseColor("#3A4E70")
                SEC = intArrayOf(
                    Color.parseColor("#1E3352"), Color.parseColor("#2A2F55"),
                    Color.parseColor("#1A2A4A"), Color.parseColor("#22375A")
                )
            }
            2 -> {
                BG = Color.parseColor("#F2EFF7"); CARD = Color.parseColor("#FFFFFF")
                PRIMARY = Color.parseColor("#5B4B9A"); PRIMARY_DARK = Color.parseColor("#453A7A")
                ON_PRIMARY = Color.parseColor("#FFFFFF"); TEXT = Color.parseColor("#2E2A3D")
                MUTED = Color.parseColor("#7C7794"); SOFT = Color.parseColor("#E4DFF1")
                BORDER = Color.parseColor("#DCD6EC"); GREEN = Color.parseColor("#4F8A6B")
                WARN = Color.parseColor("#B3402F"); BEAD = Color.parseColor("#6C5CB0")
                BEAD_OFF = Color.parseColor("#CFC8E6")
                SEC = intArrayOf(
                    Color.parseColor("#F3E4DA"), Color.parseColor("#E8DDF0"),
                    Color.parseColor("#DCE3F2"), Color.parseColor("#E2EBDD")
                )
            }
            else -> {
                BG = Color.parseColor("#F3E9DF"); CARD = Color.parseColor("#FBF6F0")
                PRIMARY = Color.parseColor("#4F6B4A"); PRIMARY_DARK = Color.parseColor("#3F5A3B")
                ON_PRIMARY = Color.parseColor("#FFFFFF"); TEXT = Color.parseColor("#43352A")
                MUTED = Color.parseColor("#8B7B6E"); SOFT = Color.parseColor("#EBDDD0")
                BORDER = Color.parseColor("#E5D6C8"); GREEN = Color.parseColor("#4F6B4A")
                WARN = Color.parseColor("#B3402F"); BEAD = Color.parseColor("#5B7A55")
                BEAD_OFF = Color.parseColor("#C9D1BE")
                SEC = intArrayOf(
                    Color.parseColor("#F8E2CF"), Color.parseColor("#E9DCE8"),
                    Color.parseColor("#DFE4F0"), Color.parseColor("#E5E8D3")
                )
            }
        }
    }

    init {
        setTheme(0)
    }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun rounded(color: Int, radius: Float): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = radius
    return g
}

fun ovalGrad(c1: Int, c2: Int): GradientDrawable {
    val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2))
    g.shape = GradientDrawable.OVAL
    return g
}

@Suppress("DEPRECATION")
fun Activity.styleBars() {
    window.statusBarColor = C.BG
    window.navigationBarColor = C.BG
    val d = window.decorView
    var f = d.systemUiVisibility
    f = if (C.themeIndex == 1) {
        f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
    } else {
        f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
    }
    d.systemUiVisibility = f
}

fun Context.tv(
    text: String,
    size: Float = 18f,
    color: Int = C.TEXT,
    bold: Boolean = false,
    center: Boolean = false,
    serif: Boolean = false
): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = size
    t.setTextColor(color)
    if (serif) {
        t.typeface = Typeface.create(Typeface.SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL)
    } else if (bold) {
        t.setTypeface(t.typeface, Typeface.BOLD)
    }
    if (center) t.gravity = Gravity.CENTER
    val lp = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
    lp.topMargin = dp(8)
    t.layoutParams = lp
    return t
}

fun Context.btn(
    text: String,
    bg: Int = C.PRIMARY,
    fg: Int = C.ON_PRIMARY,
    onClick: () -> Unit
): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = 18f
    t.setTextColor(fg)
    t.gravity = Gravity.CENTER
    t.setTypeface(t.typeface, Typeface.BOLD)
    t.setPadding(dp(16), dp(16), dp(16), dp(16))
    t.background = rounded(bg, dp(28).toFloat())
    val lp = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
    lp.topMargin = dp(14)
    t.layoutParams = lp
    t.setOnClickListener { onClick() }
    return t
}

fun Context.card(): LinearLayout {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.setPadding(dp(16), dp(14), dp(16), dp(14))
    val bg = rounded(C.CARD, dp(22).toFloat())
    bg.setStroke(dp(1), C.BORDER)
    c.background = bg
    val lp = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
    lp.topMargin = dp(12)
    c.layoutParams = lp
    return c
}

fun Context.img(res: Int, w: Int, h: Int): ImageView {
    val v = ImageView(this)
    v.setImageResource(res)
    v.scaleType = ImageView.ScaleType.FIT_CENTER
    val lp = LinearLayout.LayoutParams(dp(w), dp(h))
    lp.gravity = Gravity.CENTER_HORIZONTAL
    lp.topMargin = dp(8)
    v.layoutParams = lp
    return v
}
