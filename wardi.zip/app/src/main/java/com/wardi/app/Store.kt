package com.wardi.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Dhikr(var text: String, var count: Int)
data class Cat(var name: String, var items: MutableList<Dhikr>)

object Sections {
    val keys = listOf("morning", "evening", "sleep", "wake")

    fun title(k: String) = when (k) {
        "morning" -> "أذكار الصباح"
        "evening" -> "أذكار المساء"
        "sleep" -> "أذكار النوم"
        else -> "أذكار الاستيقاظ"
    }

    fun short(k: String) = when (k) {
        "morning" -> "الصباح"
        "evening" -> "المساء"
        "sleep" -> "النوم"
        else -> "الاستيقاظ"
    }

    fun emoji(k: String) = when (k) {
        "morning" -> "🌅"
        "evening" -> "🌇"
        "sleep" -> "🌙"
        else -> "☀️"
    }

    fun icon(k: String) = when (k) {
        "morning" -> "sunrise"
        "evening" -> "sunset"
        "sleep" -> "moon"
        else -> "sun"
    }

    fun defaultTime(k: String) = when (k) {
        "morning" -> 6 * 60
        "evening" -> 16 * 60 + 30
        "sleep" -> 22 * 60
        else -> 4 * 60 + 30
    }

    fun fmt(m: Int): String = String.format(Locale.US, "%02d:%02d", m / 60, m % 60)

    fun alertTitle(k: String) = "${emoji(k)} حان وقت ${title(k)} 🤍"

    fun alertBody(k: String) = when (k) {
        "morning" -> "وردك الصباحي بانتظارك الآن"
        "evening" -> "وردك المسائي بانتظارك، لا يفوتك"
        "sleep" -> "ليكن ذكر الله خاتمة يومك"
        else -> "يومك يبدأ بذكر الله"
    }
}

object Cheer {
    val MILESTONES = listOf(1, 3, 7, 14, 30)

    fun daysCount(n: Int): String = when {
        n == 1 -> "يوم واحد"
        n == 2 -> "يومان"
        n in 3..10 -> "$n أيام"
        else -> "$n يومًا"
    }

    fun consecutive(n: Int): String = when {
        n == 2 -> "يومين متتاليين"
        n in 3..10 -> "$n أيام متتالية"
        else -> "$n يومًا متتاليًا"
    }

    fun milestoneName(n: Int): String = when (n) {
        1 -> "1 يوم 🤍"
        3 -> "3 أيام"
        7 -> "7 أيام"
        14 -> "14 يومًا"
        30 -> "30 يومًا"
        else -> "$n"
    }

    fun streakLine(n: Int): String =
        if (n <= 0) "ابدأ سلسلتك اليوم" else "سلسلة الالتزام: ${daysCount(n)}"

    fun milestoneMessage(n: Int): String =
        if (n == 1) "بداية جميلة، أكملت وردك اليوم." else "أكملت ${consecutive(n)}."

    fun nextMilestone(n: Int): Int? = MILESTONES.firstOrNull { it > n }
}

class Store(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("hima", Context.MODE_PRIVATE)

    private val fmtDay = "yyyy-MM-dd"

    fun today(): String = SimpleDateFormat(fmtDay, Locale.US).format(Date())

    fun dayStr(offset: Int): String {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, offset)
        return SimpleDateFormat(fmtDay, Locale.US).format(c.time)
    }

    fun nowMinutes(): Int {
        val c = Calendar.getInstance()
        return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
    }

    var theme: Int
        get() = p.getInt("theme", 0)
        set(v) = p.edit().putInt("theme", v).apply()

    // ---------- الأورد الأساسية ----------
    fun getAdhkar(k: String): MutableList<Dhikr> {
        val out = mutableListOf<Dhikr>()
        try {
            val arr = JSONArray(p.getString("adhkar_$k", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Dhikr(o.getString("t"), o.getInt("c")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun saveAdhkar(k: String, list: List<Dhikr>) {
        val arr = JSONArray()
        for (d in list) {
            arr.put(JSONObject().put("t", d.text).put("c", d.count))
        }
        p.edit().putString("adhkar_$k", arr.toString()).apply()
    }

    fun getTime(k: String): Int = p.getInt("time_$k", Sections.defaultTime(k))
    fun setTime(k: String, minutes: Int) = p.edit().putInt("time_$k", minutes).apply()

    fun isDone(k: String): Boolean = p.getString("done_$k", "") == today()
    fun setDone(k: String) = p.edit().putString("done_$k", today()).apply()

    // ---------- الحجب ----------
    fun blockedApps(): MutableSet<String> =
        HashSet(p.getStringSet("blocked", emptySet<String>()) ?: emptySet<String>())

    fun setBlockedApps(s: Set<String>) = p.edit().putStringSet("blocked", HashSet(s)).apply()

    var blockingEnabled: Boolean
        get() = p.getBoolean("blocking", true)
        set(v) = p.edit().putBoolean("blocking", v).apply()

    /** هل هذا الورد يدخل في نظام الحجب؟ */
    fun blocksApps(k: String): Boolean = p.getBoolean("bl_$k", true)
    fun setBlocks(k: String, v: Boolean) = p.edit().putBoolean("bl_$k", v).apply()

    // ---------- التنبيهات لكل ورد ----------
    fun notifEnabled(k: String): Boolean = p.getBoolean("ne_$k", true)
    fun setNotif(k: String, v: Boolean) = p.edit().putBoolean("ne_$k", v).apply()
    fun soundOn(k: String): Boolean = p.getBoolean("so_$k", true)
    fun setSoundOn(k: String, v: Boolean) = p.edit().putBoolean("so_$k", v).apply()
    fun soundUri(k: String): String = p.getString("su_$k", "") ?: ""
    fun setSoundUri(k: String, v: String) = p.edit().putString("su_$k", v).apply()
    fun chanVer(k: String): Int = p.getInt("cv_$k", 0)
    fun bumpChan(k: String) = p.edit().putInt("cv_$k", chanVer(k) + 1).apply()

    // ---------- تقدّم القراءة ----------
    fun progress(k: String): Pair<Int, Int> {
        val parts = (p.getString("prog_$k", "") ?: "").split("|")
        return if (parts.size == 3 && parts[0] == today()) {
            (parts[1].toIntOrNull() ?: 0) to (parts[2].toIntOrNull() ?: 0)
        } else 0 to 0
    }

    fun setProgress(k: String, idx: Int, cnt: Int) =
        p.edit().putString("prog_$k", "${today()}|$idx|$cnt").apply()

    fun clearProgress(k: String) = p.edit().remove("prog_$k").apply()

    /** الأقسام التي حلّ وقتها اليوم ولم تكتمل بعد ولها أذكار */
    fun dueSections(): List<String> =
        Sections.keys.filter {
            getAdhkar(it).isNotEmpty() && !isDone(it) && nowMinutes() >= getTime(it)
        }

    /** الأقسام التي تحجب التطبيقات الآن */
    fun pendingSections(): List<String> = dueSections().filter { blocksApps(it) }

    /** القسم الذي يُقترح قراءته الآن */
    fun nextToRead(): String? {
        val ks = Sections.keys.filter { getAdhkar(it).isNotEmpty() && !isDone(it) }
        return ks.firstOrNull { nowMinutes() >= getTime(it) } ?: ks.firstOrNull()
    }

    fun doneCount(): Pair<Int, Int> {
        val ks = Sections.keys.filter { getAdhkar(it).isNotEmpty() }
        return ks.count { isDone(it) } to ks.size
    }

    fun todayPercent(): Int {
        val (d, t) = doneCount()
        return if (t == 0) 0 else d * 100 / t
    }

    // ---------- المكتبة (أذكار إضافية اختيارية) ----------
    fun getCats(): MutableList<Cat> {
        val raw = p.getString("cats", null)
        val out = mutableListOf<Cat>()
        if (raw == null) {
            for (n in listOf("أذكار بعد الصلاة", "أذكار دخول المنزل", "أذكار الخروج من المنزل",
                "أذكار دخول المسجد", "أذكار الخروج من المسجد", "أذكار بعد الوضوء", "أذكار السفر")) {
                out.add(Cat(n, mutableListOf()))
            }
            saveCats(out)
            return out
        }
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val items = mutableListOf<Dhikr>()
                val ia = o.getJSONArray("i")
                for (j in 0 until ia.length()) {
                    val d = ia.getJSONObject(j)
                    items.add(Dhikr(d.getString("t"), d.getInt("c")))
                }
                out.add(Cat(o.getString("n"), items))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun saveCats(list: List<Cat>) {
        val arr = JSONArray()
        for (c in list) {
            val ia = JSONArray()
            for (d in c.items) ia.put(JSONObject().put("t", d.text).put("c", d.count))
            arr.put(JSONObject().put("n", c.name).put("i", ia))
        }
        p.edit().putString("cats", arr.toString()).apply()
    }

    // ---------- سجل الالتزام ----------
    private fun doneDays(): MutableSet<String> =
        HashSet(p.getStringSet("days", emptySet<String>()) ?: emptySet<String>())

    fun firstDay(): String {
        val v = p.getString("first_day", null)
        if (v != null) return v
        val t = today()
        p.edit().putString("first_day", t).apply()
        return t
    }

    fun allDoneToday(): Boolean {
        val ks = Sections.keys.filter { getAdhkar(it).isNotEmpty() }
        return ks.isNotEmpty() && ks.all { isDone(it) }
    }

    fun recordDayIfComplete() {
        if (!allDoneToday()) return
        val days = doneDays()
        val t = today()
        if (t in days) return
        days.add(t)
        val keep = (0..400).map { dayStr(-it) }.toSet()
        val pruned = HashSet<String>()
        for (d in days) if (d in keep) pruned.add(d)
        p.edit().putStringSet("days", pruned).apply()
    }

    fun isDayDone(offset: Int): Boolean = dayStr(offset) in doneDays()

    fun streak(): Int {
        val days = doneDays()
        var offset = if (dayStr(0) in days) 0 else -1
        var n = 0
        while (dayStr(offset) in days) {
            n++
            offset--
        }
        return n
    }

    fun bestStreak(): Int {
        val days = doneDays()
        var best = 0
        var run = 0
        for (o in -400..0) {
            if (dayStr(o) in days) {
                run++
                if (run > best) best = run
            } else {
                run = 0
            }
        }
        return best
    }

    fun weekDots(): List<Boolean> {
        val days = doneDays()
        return (6 downTo 0).map { dayStr(-it) in days }
    }

    fun celebrated(): String = p.getString("celebrated", "") ?: ""
    fun setCelebrated() = p.edit().putString("celebrated", today()).apply()

    // ---------- تشخيص الحجب ----------
    fun recordEvent(pkg: String, reason: String) =
        p.edit().putString("diag_pkg", pkg).putString("diag_reason", reason)
            .putLong("diag_time", System.currentTimeMillis()).apply()

    fun markConnected() = p.edit().putLong("diag_conn", System.currentTimeMillis()).apply()
    fun diagPkg(): String = p.getString("diag_pkg", "") ?: ""
    fun diagReason(): String = p.getString("diag_reason", "") ?: ""
    fun diagTime(): Long = p.getLong("diag_time", 0L)
    fun diagConn(): Long = p.getLong("diag_conn", 0L)
}
