package com.wardi.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Dhikr(var text: String, var count: Int)

object Sections {
    val keys = listOf("morning", "evening", "sleep", "wake")

    fun title(k: String) = when (k) {
        "morning" -> "أذكار الصباح"
        "evening" -> "أذكار المساء"
        "sleep" -> "أذكار النوم"
        else -> "أذكار الاستيقاظ"
    }

    fun emoji(k: String) = when (k) {
        "morning" -> "🌅"
        "evening" -> "🌇"
        "sleep" -> "🌙"
        else -> "☀️"
    }

    fun defaultTime(k: String) = when (k) {
        "morning" -> 6 * 60
        "evening" -> 16 * 60 + 30
        "sleep" -> 22 * 60
        else -> 4 * 60 + 30
    }

    fun fmt(m: Int): String = String.format(Locale.US, "%02d:%02d", m / 60, m % 60)
}

class Store(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("wardi", Context.MODE_PRIVATE)

    fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun nowMinutes(): Int {
        val c = Calendar.getInstance()
        return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
    }

    fun getAdhkar(k: String): MutableList<Dhikr> {
        val out = mutableListOf<Dhikr>()
        try {
            val arr = JSONArray(p.getString("adhkar_$k", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Dhikr(o.getString("t"), o.getInt("c")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun saveAdhkar(k: String, list: List<Dhikr>) {
        val arr = JSONArray()
        for (d in list) {
            arr.put(JSONObject().put("t", d.text).put("c", d.count))
        }
        p.edit().putString("adhkar_$k", arr.toString()).apply()
    }

    fun getTime(k: String): Int = p.getInt("time_$k", Sections.defaultTime(k))
    fun setTime(k: String, minutes: Int) = p.edit().putInt("time_$k", minutes).apply()

    fun isDone(k: String): Boolean = p.getString("done_$k", "") == today()
    fun setDone(k: String) = p.edit().putString("done_$k", today()).apply()

    fun blockedApps(): MutableSet<String> =
        HashSet(p.getStringSet("blocked", emptySet()) ?: emptySet<String>())

    fun setBlockedApps(s: Set<String>) = p.edit().putStringSet("blocked", HashSet(s)).apply()

    var blockingEnabled: Boolean
        get() = p.getBoolean("blocking", true)
        set(v) = p.edit().putBoolean("blocking", v).apply()

    fun progress(k: String): Pair<Int, Int> {
        val parts = (p.getString("prog_$k", "") ?: "").split("|")
        return if (parts.size == 3 && parts[0] == today()) {
            (parts[1].toIntOrNull() ?: 0) to (parts[2].toIntOrNull() ?: 0)
        } else 0 to 0
    }

    fun setProgress(k: String, idx: Int, cnt: Int) =
        p.edit().putString("prog_$k", "${today()}|$idx|$cnt").apply()

    fun clearProgress(k: String) = p.edit().remove("prog_$k").apply()

    /** الأقسام التي حلّ وقتها اليوم ولم تكتمل بعد ولها أذكار */
    fun pendingSections(): List<String> =
        Sections.keys.filter {
            getAdhkar(it).isNotEmpty() && !isDone(it) && nowMinutes() >= getTime(it)
        }
}
