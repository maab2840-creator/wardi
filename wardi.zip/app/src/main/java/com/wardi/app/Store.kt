package com.wardi.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Dhikr(var text: String, var count: Int)

object Sections {
    val keys = listOf("morning", "evening", "sleep", "wake")

    fun title(k: String) = when (k) {
        "morning" -> "أذكار الصباح"
        "evening" -> "أذكار المساء"
        "sleep" -> "أذكار النوم"
        else -> "أذكار الاستيقاظ"
    }

    fun short(k: String) = when (k) {
        "morning" -> "الصباح"
        "evening" -> "المساء"
        "sleep" -> "النوم"
        else -> "الاستيقاظ"
    }

    fun emoji(k: String) = when (k) {
        "morning" -> "🌅"
        "evening" -> "🌇"
        "sleep" -> "🌙"
        else -> "☀️"
    }

    fun c1(k: String) = when (k) {
        "morning" -> 0xFFF9D7A8.toInt()
        "evening" -> 0xFFC79AB8.toInt()
        "sleep" -> 0xFF3B4A78.toInt()
        else -> 0xFFF3E3A0.toInt()
    }

    fun c2(k: String) = when (k) {
        "morning" -> 0xFFEFA45E.toInt()
        "evening" -> 0xFF7E5A8C.toInt()
        "sleep" -> 0xFF222C52.toInt()
        else -> 0xFFDDBB55.toInt()
    }

    fun defaultTime(k: String) = when (k) {
        "morning" -> 6 * 60
        "evening" -> 16 * 60 + 30
        "sleep" -> 22 * 60
        else -> 4 * 60 + 30
    }

    fun fmt(m: Int): String = String.format(Locale.US, "%02d:%02d", m / 60, m % 60)
}

object Cheer {
    private fun daysWord(n: Int) = when (n) {
        1 -> "يوم واحد"
        2 -> "يومان"
        else -> "$n أيام"
    }

    fun title(n: Int): String = when {
        n <= 1 -> "بداية مباركة"
        n == 2 -> "يومان متتاليان، ما شاء الله"
        n < 7 -> "$n أيام متتالية، ما شاء الله"
        n == 7 -> "أسبوع كامل من الثبات، تبارك الله"
        n < 30 -> "$n يومًا متتاليًا، ثبّتك الله"
        else -> "$n يومًا متتاليًا، ثبّتك الله على الخير"
    }

    fun sub(n: Int): String =
        if (n in 1..6) "بقي ${daysWord(7 - n)} ويكتمل أسبوعك الأول" else "ثباتك جميل، بارك الله في وردك"
}

class Store(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("hima", Context.MODE_PRIVATE)

    private val fmtDay = "yyyy-MM-dd"

    fun today(): String = SimpleDateFormat(fmtDay, Locale.US).format(Date())

    private fun dayStr(offset: Int): String {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, offset)
        return SimpleDateFormat(fmtDay, Locale.US).format(c.time)
    }

    fun nowMinutes(): Int {
        val c = Calendar.getInstance()
        return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
    }

    var theme: Int
        get() = p.getInt("theme", 0)
        set(v) = p.edit().putInt("theme", v).apply()

    fun getAdhkar(k: String): MutableList<Dhikr> {
        val out = mutableListOf<Dhikr>()
        try {
            val arr = JSONArray(p.getString("adhkar_$k", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Dhikr(o.getString("t"), o.getInt("c")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun saveAdhkar(k: String, list: List<Dhikr>) {
        val arr = JSONArray()
        for (d in list) {
            arr.put(JSONObject().put("t", d.text).put("c", d.count))
        }
        p.edit().putString("adhkar_$k", arr.toString()).apply()
    }

    fun getTime(k: String): Int = p.getInt("time_$k", Sections.defaultTime(k))
    fun setTime(k: String, minutes: Int) = p.edit().putInt("time_$k", minutes).apply()

    fun isDone(k: String): Boolean = p.getString("done_$k", "") == today()
    fun setDone(k: String) = p.edit().putString("done_$k", today()).apply()

    fun blockedApps(): MutableSet<String> =
        HashSet(p.getStringSet("blocked", emptySet<String>()) ?: emptySet<String>())

    fun setBlockedApps(s: Set<String>) = p.edit().putStringSet("blocked", HashSet(s)).apply()

    var blockingEnabled: Boolean
        get() = p.getBoolean("blocking", true)
        set(v) = p.edit().putBoolean("blocking", v).apply()

    fun progress(k: String): Pair<Int, Int> {
        val parts = (p.getString("prog_$k", "") ?: "").split("|")
        return if (parts.size == 3 && parts[0] == today()) {
            (parts[1].toIntOrNull() ?: 0) to (parts[2].toIntOrNull() ?: 0)
        } else 0 to 0
    }

    fun setProgress(k: String, idx: Int, cnt: Int) =
        p.edit().putString("prog_$k", "${today()}|$idx|$cnt").apply()

    fun clearProgress(k: String) = p.edit().remove("prog_$k").apply()

    /** الأقسام التي حلّ وقتها اليوم ولم تكتمل بعد ولها أذكار */
    fun pendingSections(): List<String> =
        Sections.keys.filter {
            getAdhkar(it).isNotEmpty() && !isDone(it) && nowMinutes() >= getTime(it)
        }

    // ---------- تشخيص الحجب ----------
    fun recordEvent(pkg: String, reason: String) =
        p.edit().putString("diag_pkg", pkg).putString("diag_reason", reason)
            .putLong("diag_time", System.currentTimeMillis()).apply()

    fun markConnected() = p.edit().putLong("diag_conn", System.currentTimeMillis()).apply()
    fun diagPkg(): String = p.getString("diag_pkg", "") ?: ""
    fun diagReason(): String = p.getString("diag_reason", "") ?: ""
    fun diagTime(): Long = p.getLong("diag_time", 0L)
    fun diagConn(): Long = p.getLong("diag_conn", 0L)

    // ---------- الأيام المتتالية ----------
    private fun doneDays(): MutableSet<String> =
        HashSet(p.getStringSet("days", emptySet<String>()) ?: emptySet<String>())

    fun allDoneToday(): Boolean {
        val ks = Sections.keys.filter { getAdhkar(it).isNotEmpty() }
        return ks.isNotEmpty() && ks.all { isDone(it) }
    }

    fun recordDayIfComplete() {
        if (!allDoneToday()) return
        val days = doneDays()
        val t = today()
        if (t in days) return
        days.add(t)
        val keep = (0..60).map { dayStr(-it) }.toSet()
        val pruned = HashSet<String>()
        for (d in days) if (d in keep) pruned.add(d)
        p.edit().putStringSet("days", pruned).apply()
    }

    fun streak(): Int {
        val days = doneDays()
        var offset = if (dayStr(0) in days) 0 else -1
        var n = 0
        while (dayStr(offset) in days) {
            n++
            offset--
        }
        return n
    }

    fun weekDots(): List<Boolean> {
        val days = doneDays()
        return (6 downTo 0).map { dayStr(-it) in days }
    }
}
