package com.wardi.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Collections

data class AppItem(val pkg: String, val label: String, val icon: Drawable)

class MainActivity : Activity() {
    companion object {
        var splashDone = false

        val BRANDS = listOf("شاومي / ريدمي", "سامسونج", "هواوي / هونر", "أوبو / ريلمي / وان بلس", "فيفو", "أخرى")
        val GUIDE = listOf(
            "١. معلومات التطبيق ← «التشغيل التلقائي» (Autostart): فعّله.\n" +
                "٢. معلومات التطبيق ← توفير البطارية: اختر «بدون قيود».\n" +
                "٣. معلومات التطبيق ← أذونات أخرى: فعّل «عرض النوافذ المنبثقة أثناء التشغيل في الخلفية».\n" +
                "٤. افتح التطبيقات الأخيرة، واضغط مطولًا على بطاقة حِمى، ثم اختر القفل.",
            "١. الإعدادات ← البطارية ← حدود استخدام الخلفية ← التطبيقات التي لا تنام أبدًا: أضف حِمى.\n" +
                "٢. معلومات التطبيق ← البطارية: اختر «غير مقيّد».\n" +
                "٣. الإعدادات ← التطبيقات ← الوصول الخاص ← الظهور فوق التطبيقات: فعّل حِمى.\n" +
                "٤. الإعدادات ← تسهيلات الاستخدام ← التطبيقات المثبّتة ← حِمى: شغّلها.",
            "١. الإعدادات ← البطارية ← تشغيل التطبيقات (App launch) ← حِمى: اختر «إدارة يدوية» وفعّل التشغيل التلقائي والتشغيل الثانوي والتشغيل في الخلفية.\n" +
                "٢. الإعدادات ← التطبيقات ← حِمى ← البطارية: اسمح بالنشاط في الخلفية.\n" +
                "٣. الإعدادات ← التطبيقات ← الوصول الخاص ← الظهور فوق التطبيقات: فعّل حِمى.",
            "١. الإعدادات ← البطارية ← حِمى (أو معلومات التطبيق ← استخدام البطارية): اسمح بالنشاط في الخلفية.\n" +
                "٢. معلومات التطبيق ← «التشغيل التلقائي»: فعّله.\n" +
                "٣. اقفل حِمى في قائمة التطبيقات الأخيرة.",
            "١. الإعدادات ← البطارية ← استهلاك الطاقة في الخلفية ← حِمى: اسمح بالاستهلاك العالي في الخلفية.\n" +
                "٢. الإعدادات ← التطبيقات ← التشغيل التلقائي: فعّل حِمى.\n" +
                "٣. اقفل حِمى في قائمة التطبيقات الأخيرة.",
            "١. معلومات التطبيق ← البطارية: اختر «بدون قيود» أو أوقف تحسين البطارية لحِمى.\n" +
                "٢. إن وجدت في هاتفك خيار «التشغيل التلقائي» أو «النشاط في الخلفية» فعّله.\n" +
                "٣. اقفل حِمى في قائمة التطبيقات الأخيرة إن أتاح هاتفك ذلك.\n" +
                "٤. تختلف أسماء القوائم بين الهواتف، فابحث عن «حِمى» في الإعدادات."
        )
    }

    private lateinit var store: Store
    private var backAction: (() -> Unit)? = null
    private var current: (() -> Unit)? = null
    private var cachedApps: List<AppItem>? = null
    private var brandSel = -1
    private var pickKey = "morning"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        C.setTheme(store.theme)
        styleBars()
        store.firstDay()
        Scheduler.scheduleAll(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        if (splashDone) showHome() else showSplash()
    }

    override fun onResume() {
        super.onResume()
        current?.invoke()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val b = backAction
        if (b != null) b() else super.onBackPressed()
    }

    // ================= الهيكل العام =================
    private fun showSplash() {
        current = null
        backAction = null
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(C.BG)
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.addView(img(R.drawable.art_shield, 200, 225))
        root.addView(tv("حِمى", 52f, C.TEXT, true, true, true))
        root.addView(tv("وردك أولًا .. ثم افتح ما تشاء", 16f, C.MUTED, false, true))
        root.addView(img(R.drawable.deco_divider, 160, 24))
        setContentView(root)
        Handler(Looper.getMainLooper()).postDelayed({
            splashDone = true
            if (!isFinishing) showHome()
        }, 1400)
    }

    private fun page(navSel: Int, back: (() -> Unit)?, title: String?): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(16), dp(20), dp(24))
        val sv = ScrollView(this)
        sv.addView(col)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(C.BG)
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        if (navSel >= 0) root.addView(navBar(navSel))
        setContentView(root)
        backAction = back
        if (title != null) col.addView(header(title, if (navSel < 0) back else null))
        return col
    }

    private fun header(title: String, back: (() -> Unit)?): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val arrow = TextView(this)
        arrow.text = if (back != null) "→" else ""
        arrow.textSize = 26f
        arrow.setTextColor(C.PRIMARY_DARK)
        arrow.gravity = Gravity.CENTER
        arrow.layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        if (back != null) arrow.setOnClickListener { back() }
        val t = tv(title, 22f, C.PRIMARY_DARK, true, true, true)
        t.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val sp = View(this)
        sp.layoutParams = LinearLayout.LayoutParams(dp(44), 1)
        row.addView(arrow)
        row.addView(t)
        row.addView(sp)
        return row
    }

    private fun navBar(sel: Int): View {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(C.CARD)
        bar.setPadding(dp(8), dp(6), dp(8), dp(6))
        val items = listOf("home" to "الرئيسية", "apps" to "التطبيقات", "settings" to "الإعدادات")
        items.forEachIndexed { i, item ->
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER
            cell.setPadding(0, dp(4), 0, dp(4))
            cell.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            val pill = FrameLayout(this)
            if (i == sel) pill.background = rounded(C.SOFT, dp(16).toFloat())
            pill.setPadding(dp(18), dp(4), dp(18), dp(4))
            pill.addView(
                IconView(this, item.first, if (i == sel) C.PRIMARY else C.MUTED),
                FrameLayout.LayoutParams(dp(26), dp(26))
            )
            val plp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            plp.gravity = Gravity.CENTER_HORIZONTAL
            cell.addView(pill, plp)
            val b = TextView(this)
            b.text = item.second
            b.textSize = 12f
            b.gravity = Gravity.CENTER
            b.setTextColor(if (i == sel) C.PRIMARY_DARK else C.MUTED)
            if (i == sel) b.setTypeface(b.typeface, Typeface.BOLD)
            cell.addView(b)
            cell.setOnClickListener {
                when (i) {
                    0 -> showHome()
                    1 -> showApps()
                    else -> showSettings()
                }
            }
            bar.addView(cell)
        }
        return bar
    }

    private fun chip(text: String, selected: Boolean, onClick: () -> Unit): TextView {
        val c = TextView(this)
        c.text = text
        c.textSize = 14f
        c.gravity = Gravity.CENTER
        c.setPadding(dp(16), dp(8), dp(16), dp(8))
        c.setTextColor(if (selected) C.ON_PRIMARY else C.TEXT)
        c.background = rounded(if (selected) C.PRIMARY else C.SOFT, dp(20).toFloat())
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.marginEnd = dp(8)
        c.layoutParams = lp
        c.setOnClickListener { onClick() }
        return c
    }

    private fun chipsRow(labels: List<String>, selected: Int, onPick: (Int) -> Unit): View {
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        labels.forEachIndexed { i, l -> row.addView(chip(l, i == selected) { onPick(i) }) }
        hs.addView(row)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(12)
        hs.layoutParams = lp
        return hs
    }

    private fun rowCard(): LinearLayout {
        val r = card()
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        return r
    }

    private fun textsBox(): LinearLayout {
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.marginStart = dp(14)
        lp.marginEnd = dp(8)
        t.layoutParams = lp
        return t
    }

    private fun progressBar(pct: Int): ProgressBar {
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100
        bar.progress = pct
        bar.progressTintList = ColorStateList.valueOf(C.PRIMARY)
        bar.progressBackgroundTintList = ColorStateList.valueOf(C.BEAD_OFF)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8))
        lp.topMargin = dp(10)
        bar.layoutParams = lp
        return bar
    }

    private fun switchTint(sw: Switch) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(C.PRIMARY, C.MUTED))
        sw.trackTintList = ColorStateList(states, intArrayOf(C.BEAD_OFF, C.BORDER))
    }

    private fun switchRow(label: String, on: Boolean, onChange: (Boolean) -> Unit): View {
        val sw = Switch(this)
        sw.text = label
        sw.textSize = 16f
        sw.setTextColor(C.TEXT)
        switchTint(sw)
        sw.isChecked = on
        sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(10)
        sw.layoutParams = lp
        return sw
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun startWird(k: String) {
        startActivity(Intent(this, WirdActivity::class.java).putExtra("key", k))
    }

    // ================= الرئيسية =================
    private fun showHome() {
        current = { showHome() }
        val col = page(0, null, null)
        col.addView(tv("السلام عليكم 🤍", 16f, C.MUTED, false, true))
        col.addView(tv("حِمى", 38f, C.TEXT, true, true, true))
        col.addView(img(R.drawable.deco_divider, 140, 22))

        if (!isAccessibilityOn() || !Settings.canDrawOverlays(this)) {
            val w = card()
            w.addView(tv("⚠️ الحجب غير مفعّل بعد. اضغط هنا لإعداد حِمى.", 15f, C.WARN, true))
            w.setOnClickListener { showProtection() }
            col.addView(w)
        }

        col.addView(progressCard())
        col.addView(streakCard())
        col.addView(btn("ابدأ وردك") {
            val k = store.nextToRead()
            if (k == null) {
                val (_, t) = store.doneCount()
                toast(if (t == 0) "أضف أذكارًا إلى الأقسام أولًا" else "أكملت كل أورد اليوم 🤍")
            } else {
                startWird(k)
            }
        })

        Sections.keys.forEachIndexed { i, k -> col.addView(sectionCard(i, k)) }
    }

    private fun progressCard(): View {
        val (d, t) = store.doneCount()
        val pct = store.todayPercent()
        val c = card()
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        val a = tv("إنجاز اليوم", 16f, C.TEXT, true)
        a.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val b = tv("$pct%", 18f, C.PRIMARY_DARK, true)
        b.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        head.addView(a)
        head.addView(b)
        c.addView(head)
        c.addView(progressBar(pct))
        c.addView(tv(if (t == 0) "أضف أذكارًا في الأقسام لتبدأ" else "$d من $t أورد مكتملة اليوم", 13f, C.MUTED))
        return c
    }

    private fun streakCard(): View {
        val st = store.streak()
        val c = card()
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val ic = icon("flame", C.PRIMARY, 24)
        (ic.layoutParams as LinearLayout.LayoutParams).marginEnd = dp(8)
        head.addView(ic)
        val t = tv(Cheer.streakLine(st), 17f, C.PRIMARY_DARK, true, false, true)
        t.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        head.addView(t)
        c.addView(head)
        val dots = LinearLayout(this)
        dots.orientation = LinearLayout.HORIZONTAL
        val dlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        dlp.topMargin = dp(10)
        dots.layoutParams = dlp
        for (on in store.weekDots()) {
            val d = View(this)
            d.background = oval(if (on) C.PRIMARY else C.BEAD_OFF)
            val lp = LinearLayout.LayoutParams(dp(20), dp(20))
            lp.marginEnd = dp(8)
            dots.addView(d, lp)
        }
        c.addView(dots)
        c.addView(tv("اضغط لعرض سجل الالتزام", 12f, C.MUTED))
        c.setOnClickListener { showHistory() }
        return c
    }

    private fun sectionCard(i: Int, k: String): View {
        val n = store.getAdhkar(k).size
        val done = store.isDone(k)
        val pending = k in store.pendingSections()
        val status = when {
            n == 0 -> "لا توجد أذكار بعد"
            done -> "مكتمل ✓"
            else -> "غير مكتمل"
        }
        val sub = when {
            n == 0 -> "اضغط ✎ لإضافة الأذكار"
            done -> "$n أذكار • ${Sections.fmt(store.getTime(k))}"
            pending -> "التطبيقات محجوبة حتى تكمله 🔒"
            else -> "$n أذكار • من ${Sections.fmt(store.getTime(k))}"
        }
        val row = rowCard()
        row.addView(iconCircle(Sections.icon(k), C.IC_BG[i], C.IC_FG[i], 52))
        val texts = textsBox()
        texts.addView(tv(Sections.title(k), 19f, C.TEXT, true, false, true))
        texts.addView(tv(status, 14f, if (done) C.GREEN else C.MUTED, true))
        texts.addView(tv(sub, 13f, C.MUTED))
        row.addView(texts)
        val edit = TextView(this)
        edit.text = "✎"
        edit.textSize = 24f
        edit.setTextColor(C.MUTED)
        edit.gravity = Gravity.CENTER
        edit.layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        edit.setOnClickListener { showSection(k) }
        row.addView(edit)
        row.setOnClickListener {
            if (store.getAdhkar(k).isEmpty()) showSection(k) else startWird(k)
        }
        return row
    }

    // ================= إدارة أذكار ورد أساسي =================
    private fun smallBtn(text: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 14f
        t.setTextColor(C.PRIMARY_DARK)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(8), dp(10), dp(8), dp(10))
        t.background = rounded(C.SOFT, dp(12).toFloat())
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.marginStart = dp(4)
        lp.marginEnd = dp(4)
        t.layoutParams = lp
        t.setOnClickListener { onClick() }
        return t
    }

    private fun promptText(title: String, initial: String, onOk: (String) -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(10), dp(20), 0)
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val e = EditText(this)
        e.setText(initial)
        box.addView(e)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val t = e.text.toString().trim()
                if (t.isNotEmpty()) onOk(t)
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun editDhikr(list: MutableList<Dhikr>, index: Int, save: () -> Unit, refresh: () -> Unit) {
        val edit = if (index >= 0) list[index] else null
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(10), dp(20), 0)
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val t = EditText(this)
        t.hint = "نص الذكر"
        t.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        t.minLines = 2
        t.setText(edit?.text ?: "")
        val n = EditText(this)
        n.hint = "عدد التكرار"
        n.inputType = InputType.TYPE_CLASS_NUMBER
        n.setText((edit?.count ?: 1).toString())
        box.addView(t)
        box.addView(n)
        AlertDialog.Builder(this)
            .setTitle(if (edit == null) "إضافة ذكر" else "تعديل الذكر")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val text = t.text.toString().trim()
                val c = (n.text.toString().toIntOrNull() ?: 1).coerceAtLeast(1)
                if (text.isNotEmpty()) {
                    if (edit != null) list[index] = Dhikr(text, c) else list.add(Dhikr(text, c))
                    save()
                    refresh()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun dhikrCard(list: MutableList<Dhikr>, i: Int, save: () -> Unit, refresh: () -> Unit, open: (() -> Unit)?): View {
        val d = list[i]
        val outer = LinearLayout(this)
        outer.orientation = LinearLayout.VERTICAL
        val bg = rounded(C.CARD, dp(22).toFloat())
        bg.setStroke(dp(1), C.BORDER)
        outer.background = bg
        outer.clipToOutline = true
        val olp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        olp.topMargin = dp(12)
        outer.layoutParams = olp

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.gravity = Gravity.CENTER_HORIZONTAL
        body.setPadding(dp(18), dp(18), dp(18), dp(14))
        body.addView(tv(d.text, 19f, C.TEXT, true, true, true))
        outer.addView(body)

        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.setPadding(dp(10), 0, dp(10), dp(8))
        actions.addView(smallBtn("تعديل") { editDhikr(list, i, save, refresh) })
        actions.addView(smallBtn("حذف") {
            AlertDialog.Builder(this)
                .setMessage("حذف هذا الذكر؟")
                .setPositiveButton("حذف") { _, _ ->
                    list.removeAt(i)
                    save()
                    refresh()
                }
                .setNegativeButton("إلغاء", null)
                .show()
        })
        actions.addView(smallBtn("▲") {
            if (i > 0) {
                Collections.swap(list, i, i - 1)
                save()
                refresh()
            }
        })
        actions.addView(smallBtn("▼") {
            if (i < list.size - 1) {
                Collections.swap(list, i, i + 1)
                save()
                refresh()
            }
        })
        outer.addView(actions)

        val bar = TextView(this)
        bar.text = "${d.count}"
        bar.textSize = 20f
        bar.setTypeface(bar.typeface, Typeface.BOLD)
        bar.setTextColor(C.ON_PRIMARY)
        bar.gravity = Gravity.CENTER
        bar.setPadding(0, dp(14), 0, dp(14))
        bar.background = C.PRIMARY.let { col ->
            val g = android.graphics.drawable.GradientDrawable()
            g.setColor(col)
            g.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, dp(22).toFloat(), dp(22).toFloat(), dp(22).toFloat(), dp(22).toFloat())
            g
        }
        outer.addView(bar)

        if (open != null) body.setOnClickListener { open() }
        return outer
    }

    private fun showSection(k: String) {
        current = { showSection(k) }
        val col = page(-1, { showHome() }, "إدارة الأذكار")
        col.addView(chipsRow(Sections.keys.map { Sections.short(it) }, Sections.keys.indexOf(k)) {
            showSection(Sections.keys[it])
        })

        val rule = card()
        rule.addView(tv("شرط الحجب لهذا الورد", 15f, C.PRIMARY_DARK, true, false, true))
        val t = Sections.fmt(store.getTime(k))
        rule.addView(
            tv(
                if (store.blocksApps(k)) {
                    "بعد الساعة $t تُحجب التطبيقات المختارة حتى تكمل كل أذكار هذا القسم، ثم تُفتح حتى اليوم التالي. لن يحجب هذا القسم شيئًا ما دام بلا أذكار."
                } else {
                    "هذا الورد لا يحجب التطبيقات، لكنه يدخل في حساب إنجاز اليوم. يمكنك تفعيل الحجب له من الإعدادات."
                },
                13f, C.TEXT
            )
        )
        col.addView(rule)

        val list = store.getAdhkar(k)
        val save = { store.saveAdhkar(k, list); store.clearProgress(k) }
        val refresh = { showSection(k) }
        col.addView(btn("＋  إضافة ذكر جديد", C.CARD, C.PRIMARY_DARK) { editDhikr(list, -1, save, refresh) })
        if (list.isEmpty()) col.addView(tv("لا توجد أذكار في هذا القسم بعد.", 15f, C.MUTED, false, true))
        list.forEachIndexed { i, _ -> col.addView(dhikrCard(list, i, save, refresh, null)) }
        if (list.isNotEmpty()) col.addView(btn("ابدأ الورد") { startWird(k) })
    }

    // ================= التطبيقات المحظورة =================
    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(q, 0)
            .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    private fun appRow(a: AppItem, chosen: MutableSet<String>): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(14), dp(10), dp(14), dp(10))
        row.background = rounded(C.CARD, dp(16).toFloat())
        val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rlp.topMargin = dp(8)
        row.layoutParams = rlp
        val ic = ImageView(this)
        ic.setImageDrawable(a.icon)
        ic.layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
        val name = TextView(this)
        name.text = a.label
        name.textSize = 17f
        name.setTextColor(C.TEXT)
        val nlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        nlp.marginStart = dp(12)
        nlp.marginEnd = dp(8)
        name.layoutParams = nlp
        val sw = Switch(this)
        switchTint(sw)
        sw.isChecked = a.pkg in chosen
        sw.setOnCheckedChangeListener { _, on ->
            if (on) chosen.add(a.pkg) else chosen.remove(a.pkg)
            store.setBlockedApps(chosen)
        }
        row.addView(ic)
        row.addView(name)
        row.addView(sw)
        return row
    }

    private fun showApps() {
        current = { showApps() }
        val col = page(1, { showHome() }, "التطبيقات المحظورة")

        val master = card()
        master.addView(switchRow("حظر التطبيقات", store.blockingEnabled) { store.blockingEnabled = it })
        master.addView(tv("سيتم منع التطبيقات المحددة من الاستخدام حتى إكمال الورد المطلوب.", 13f, C.MUTED))
        col.addView(master)

        val search = EditText(this)
        search.hint = "ابحث عن تطبيق..."
        search.textSize = 16f
        search.setTextColor(C.TEXT)
        search.setHintTextColor(C.MUTED)
        search.isSingleLine = true
        search.setPadding(dp(16), dp(12), dp(16), dp(12))
        search.background = rounded(C.CARD, dp(20).toFloat())
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.topMargin = dp(12)
        search.layoutParams = slp
        col.addView(search)
        val listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        col.addView(listBox)

        val apps = cachedApps ?: loadApps().also { cachedApps = it }
        val chosen = store.blockedApps()
        fun render(q: String) {
            listBox.removeAllViews()
            for (a in apps) {
                if (q.isNotEmpty() && !a.label.contains(q, ignoreCase = true)) continue
                listBox.addView(appRow(a, chosen))
            }
        }
        render("")
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                render(s?.toString()?.trim() ?: "")
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    // ================= الإعدادات =================
    private fun soundName(k: String): String {
        val u = store.soundUri(k)
        if (u.isEmpty()) return "الافتراضية"
        return try {
            RingtoneManager.getRingtone(this, Uri.parse(u)).getTitle(this)
        } catch (e: Exception) {
            "مخصصة"
        }
    }

    private fun pickSound(k: String) {
        pickKey = k
        val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
        val cur = store.soundUri(k)
        if (cur.isNotEmpty()) i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(cur))
        try {
            startActivityForResult(i, 77)
        } catch (e: Exception) {
            toast("تعذّر فتح اختيار النغمات على هذا الهاتف")
        }
    }

    @Deprecated("Deprecated in Java")
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77 && resultCode == RESULT_OK) {
            val uri = data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            store.setSoundUri(pickKey, uri?.toString() ?: "")
            Notif.bump(this, store, pickKey)
            showSettings()
        }
    }

    private fun wirdSettingsCard(col: LinearLayout, i: Int, k: String) {
        val c = card()
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(iconCircle(Sections.icon(k), C.IC_BG[i], C.IC_FG[i], 40))
        val ht = tv(Sections.title(k), 18f, C.PRIMARY_DARK, true, false, true)
        val hlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        hlp.marginStart = dp(12)
        ht.layoutParams = hlp
        head.addView(ht)
        c.addView(head)

        val t = store.getTime(k)
        c.addView(btn("الوقت: ${Sections.fmt(t)}", C.SOFT, C.PRIMARY_DARK) {
            TimePickerDialog(this, { _, h, m ->
                store.setTime(k, h * 60 + m)
                Scheduler.scheduleAll(this)
                showSettings()
            }, t / 60, t % 60, true).show()
        })
        c.addView(switchRow("يحجب التطبيقات حتى أكمله", store.blocksApps(k)) { store.setBlocks(k, it) })
        c.addView(switchRow("تنبيه عند وقت الورد", store.notifEnabled(k)) {
            store.setNotif(k, it)
            Scheduler.scheduleAll(this)
        })
        c.addView(switchRow("صوت التنبيه", store.soundOn(k)) {
            store.setSoundOn(k, it)
            Notif.bump(this, store, k)
        })
        c.addView(btn("نغمة التنبيه: ${soundName(k)}", C.SOFT, C.PRIMARY_DARK) { pickSound(k) })
        c.addView(btn("جرّب التنبيه الآن", C.SOFT, C.PRIMARY_DARK) { Notif.wirdAlert(this, k) })
        col.addView(c)
    }

    private fun showSettings() {
        current = { showSettings() }
        val col = page(2, { showHome() }, "الإعدادات")

        col.addView(tv("الأورد الأساسية والتنبيهات", 17f, C.PRIMARY_DARK, true, false, true))
        Sections.keys.forEachIndexed { i, k -> wirdSettingsCard(col, i, k) }
        col.addView(tv("مستوى صوت الإشعارات يتحكم فيه نظام أندرويد من أزرار الصوت في هاتفك.", 12f, C.MUTED))

        col.addView(tv("المظهر", 17f, C.PRIMARY_DARK, true, false, true))
        col.addView(chipsRow(C.THEME_NAMES, C.themeIndex) {
            store.theme = it
            C.setTheme(it)
            styleBars()
            showSettings()
        })

        col.addView(tv("الحماية والسجل", 17f, C.PRIMARY_DARK, true, false, true))
        col.addView(btn("إعداد حِمى والصلاحيات") { showProtection() })
        col.addView(btn("سجل الالتزام", C.CARD, C.PRIMARY_DARK) { showHistory() })
        col.addView(tv("حِمى يعمل بدون إنترنت، ولا يجمع أي بيانات، وكل ما تكتبه محفوظ على هاتفك فقط.", 13f, C.MUTED, false, true))
    }

    // ================= سجل الالتزام =================
    private fun statCard(value: String, label: String): LinearLayout {
        val c = card()
        c.gravity = Gravity.CENTER_HORIZONTAL
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.marginStart = dp(4)
        lp.marginEnd = dp(4)
        lp.topMargin = dp(12)
        c.layoutParams = lp
        c.addView(tv(value, 26f, C.PRIMARY_DARK, true, true, true))
        c.addView(tv(label, 13f, C.MUTED, false, true))
        return c
    }

    private fun showHistory() {
        current = { showHistory() }
        val col = page(-1, { showHome() }, "سجل الالتزام")
        val st = store.streak()
        val best = store.bestStreak()

        val stats = LinearLayout(this)
        stats.orientation = LinearLayout.HORIZONTAL
        stats.addView(statCard(Cheer.daysCount(st), "سلسلة الالتزام الحالية"))
        stats.addView(statCard(Cheer.daysCount(best), "أطول سلسلة"))
        col.addView(stats)

        col.addView(tv("آخر 4 أسابيع", 17f, C.PRIMARY_DARK, true, false, true))
        val cal = card()
        val first = store.firstDay()
        for (r in 0 until 4) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            rlp.topMargin = dp(6)
            row.layoutParams = rlp
            for (cidx in 0 until 7) {
                val off = -27 + r * 7 + cidx
                val ds = store.dayStr(off)
                val done = store.isDayDone(off)
                val cell = TextView(this)
                cell.text = ds.substring(8, 10).toInt().toString()
                cell.textSize = 13f
                cell.gravity = Gravity.CENTER
                val bg = oval(if (done) C.PRIMARY else if (ds < first) C.CARD else C.SOFT)
                if (off == 0) bg.setStroke(dp(2), C.PRIMARY)
                cell.background = bg
                cell.setTextColor(if (done) C.ON_PRIMARY else C.MUTED)
                val lp = LinearLayout.LayoutParams(0, dp(38), 1f)
                lp.marginStart = dp(3)
                lp.marginEnd = dp(3)
                cell.layoutParams = lp
                row.addView(cell)
            }
            cal.addView(row)
        }
        cal.addView(tv("الدائرة الممتلئة: يوم مكتمل • الرمادية: يوم غير مكتمل", 12f, C.MUTED))
        col.addView(cal)

        col.addView(tv("الإنجازات", 17f, C.PRIMARY_DARK, true, false, true))
        for (m in Cheer.MILESTONES) {
            val got = best >= m
            val row = rowCard()
            row.addView(iconCircle(if (got) "check" else "lock", if (got) C.PRIMARY else C.SOFT, if (got) C.ON_PRIMARY else C.MUTED, 40))
            val texts = textsBox()
            texts.addView(tv(Cheer.milestoneName(m), 17f, C.TEXT, true))
            texts.addView(tv(if (got) "تم تحقيقه، ما شاء الله 🤍" else "أكمل الأورد ${Cheer.consecutive(m)}", 13f, C.MUTED))
            row.addView(texts)
            col.addView(row)
        }

        val rule = card()
        rule.addView(tv("كيف يُحسب إنجاز اليوم؟", 15f, C.PRIMARY_DARK, true, false, true))
        rule.addView(
            tv(
                "يُحسب اليوم مكتملًا عند إكمال كل الأورد التي فيها أذكار (الصباح والمساء والنوم والاستيقاظ). " +
                    "إن فاتك يوم تبدأ السلسلة من جديد بلا لوم.",
                13f, C.TEXT
            )
        )
        col.addView(rule)
    }

    // ================= إعداد حِمى والصلاحيات =================
    private fun isAccessibilityOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(this, BlockerService::class.java)
        return s.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    private fun detectBrand(): Int {
        val m = (Build.MANUFACTURER + " " + Build.BRAND).lowercase()
        return when {
            "xiaomi" in m || "redmi" in m || "poco" in m -> 0
            "samsung" in m -> 1
            "huawei" in m || "honor" in m -> 2
            "oppo" in m || "realme" in m || "oneplus" in m -> 3
            "vivo" in m || "iqoo" in m -> 4
            else -> 5
        }
    }

    private fun permCard(col: LinearLayout, title: String, why: String, on: Boolean, actionText: String, action: () -> Unit) {
        val c = card()
        c.addView(tv(title, 17f, C.PRIMARY_DARK, true, false, true))
        c.addView(tv(why, 14f, C.TEXT))
        c.addView(tv(if (on) "✓ مفعلة" else "✕ غير مفعلة", 15f, if (on) C.GREEN else C.WARN, true))
        c.addView(btn(actionText, C.PRIMARY) { action() })
        col.addView(c)
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    private fun ago(t: Long): String {
        val sec = (System.currentTimeMillis() - t) / 1000
        return if (sec < 60) "قبل $sec ثانية" else "قبل ${sec / 60} دقيقة"
    }

    private fun diagCard(col: LinearLayout) {
        val c = card()
        c.addView(tv("تشخيص الحجب", 17f, C.PRIMARY_DARK, true, false, true))
        val conn = store.diagConn()
        c.addView(
            tv(
                if (conn == 0L) "خدمة الحجب: لم تتصل بعد. أوقفها ثم شغّلها من إمكانية الوصول."
                else "خدمة الحجب: متصلة ✓",
                14f, if (conn == 0L) C.WARN else C.GREEN, true
            )
        )
        val t = store.diagTime()
        if (t == 0L) {
            c.addView(tv("لم ترصد الخدمة أي تطبيق بعد. افتح أي تطبيق ثم ارجع إلى هنا.", 14f, C.TEXT))
        } else {
            c.addView(tv("آخر تطبيق رصدته: ${appLabel(store.diagPkg())} (${ago(t)})", 14f, C.TEXT))
            c.addView(tv("النتيجة: ${store.diagReason()}", 14f, C.TEXT, true))
        }
        c.addView(tv("عدد التطبيقات المختارة للحجب: ${store.blockedApps().size}", 14f, C.TEXT))
        val pend = store.pendingSections()
        c.addView(
            tv(
                "الورد الذي يحجب الآن: " + if (pend.isEmpty()) "لا يوجد" else pend.joinToString("، ") { Sections.title(it) },
                14f, C.TEXT
            )
        )
        c.addView(btn("تحديث", C.SOFT, C.PRIMARY_DARK) { showProtection() })
        col.addView(c)
    }

    private fun showProtection() {
        current = { showProtection() }
        if (brandSel < 0) brandSel = detectBrand()
        val col = page(-1, { showSettings() }, "إعداد حِمى")
        col.addView(tv("لمنع فتح التطبيقات قبل إكمال الورد، يحتاج حِمى إلى الصلاحيات التالية. لا نطلب أي صلاحية غير ضرورية.", 14f, C.MUTED, false, true))

        permCard(
            col, "١. خدمة إمكانية الوصول (Accessibility)",
            "تُخبر حِمى بأن تطبيقًا محظورًا فُتح، فتعرض شاشة حِمى بدلًا منه. لا تقرأ أي محتوى ولا ترسل بيانات.\n" +
                "إن كان الخيار رماديًا: معلومات التطبيق ← ⋮ ← «السماح بالإعدادات المقيّدة»، ثم ارجع وفعّلها.",
            isAccessibilityOn(), "فتح إعدادات إمكانية الوصول"
        ) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        permCard(
            col, "٢. الظهور فوق التطبيقات (Display over other apps)",
            "يساعد حِمى على الظهور فورًا فوق التطبيق المحظور.",
            Settings.canDrawOverlays(this), "فتح الإعدادات"
        ) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        permCard(
            col, "٣. الإشعارات",
            "لتنبيهك عند حلول وقت الورد وعند محاولة فتح تطبيق محظور.",
            nm.areNotificationsEnabled(), "السماح بالإشعارات"
        ) {
            startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            )
        }

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        permCard(
            col, "٤. استثناء حِمى من توفير البطارية",
            "حتى لا يوقف النظام حِمى في الخلفية فتتأخر التنبيهات أو يتعطل الحجب.",
            pm.isIgnoringBatteryOptimizations(packageName), "فتح إعدادات البطارية"
        ) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }

        col.addView(tv("لا يحتاج حِمى إلى إذن «الوصول إلى بيانات الاستخدام»، فلم نطلبه.", 12f, C.MUTED))

        diagCard(col)

        col.addView(tv("إعدادات إضافية حسب نوع هاتفك", 17f, C.PRIMARY_DARK, true, false, true))
        col.addView(chipsRow(BRANDS, brandSel) {
            brandSel = it
            showProtection()
        })
        val g = card()
        g.addView(tv(GUIDE[brandSel], 14f, C.TEXT))
        g.addView(tv("قد تختلف أسماء القوائم قليلًا حسب إصدار هاتفك.", 12f, C.MUTED))
        col.addView(g)
        col.addView(btn("فتح معلومات التطبيق", C.CARD, C.PRIMARY_DARK) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })

        val lim = card()
        lim.addView(tv("ما الذي تستطيع حِمى منعه فعليًا؟", 16f, C.PRIMARY_DARK, true, false, true))
        lim.addView(
            tv(
                "تحجب التطبيقات المختارة عند فتحها ما دام الورد غير مكتمل، لكن الحماية ليست مطلقة: " +
                    "يمكن إيقاف خدمة إمكانية الوصول من إعدادات الهاتف، وأندرويد لا يسمح لتطبيق عادي بمنع ذلك. " +
                    "الحجب يعتمد على التزامك أكثر من كونه قفلًا لا يُكسر.",
                14f, C.TEXT
            )
        )
        col.addView(lim)
    }
}
