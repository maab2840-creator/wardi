package com.wardi.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Collections

data class AppItem(val pkg: String, val label: String, val icon: Drawable)

class MainActivity : Activity() {
    companion object {
        var splashDone = false

        val BRANDS = listOf("شاومي / ريدمي", "سامسونج", "هواوي / هونر", "أوبو / ريلمي / وان بلس", "فيفو", "أخرى")
        val GUIDE = listOf(
            "١. معلومات التطبيق ← «التشغيل التلقائي» (Autostart): فعّله.\n" +
                "٢. معلومات التطبيق ← توفير البطارية: اختر «بدون قيود».\n" +
                "٣. معلومات التطبيق ← أذونات أخرى: فعّل «عرض النوافذ المنبثقة أثناء التشغيل في الخلفية».\n" +
                "٤. افتح التطبيقات الأخيرة، واضغط مطولًا على بطاقة حِمى، ثم اختر القفل 🔒.",
            "١. الإعدادات ← البطارية ← حدود استخدام الخلفية ← التطبيقات التي لا تنام أبدًا: أضف حِمى.\n" +
                "٢. معلومات التطبيق ← البطارية: اختر «غير مقيّد».\n" +
                "٣. الإعدادات ← التطبيقات ← الوصول الخاص ← الظهور فوق التطبيقات: فعّل حِمى.\n" +
                "٤. الإعدادات ← تسهيلات الاستخدام ← التطبيقات المثبّتة ← حِمى: شغّلها.",
            "١. الإعدادات ← البطارية ← تشغيل التطبيقات (App launch) ← حِمى: اختر «إدارة يدوية» وفعّل التشغيل التلقائي والتشغيل الثانوي والتشغيل في الخلفية.\n" +
                "٢. الإعدادات ← التطبيقات ← حِمى ← البطارية: اسمح بالنشاط في الخلفية.\n" +
                "٣. الإعدادات ← التطبيقات ← الوصول الخاص ← الظهور فوق التطبيقات: فعّل حِمى.",
            "١. الإعدادات ← البطارية ← حِمى (أو معلومات التطبيق ← استخدام البطارية): اسمح بالنشاط في الخلفية.\n" +
                "٢. معلومات التطبيق ← «التشغيل التلقائي»: فعّله.\n" +
                "٣. اقفل حِمى في قائمة التطبيقات الأخيرة.",
            "١. الإعدادات ← البطارية ← استهلاك الطاقة في الخلفية ← حِمى: اسمح بالاستهلاك العالي في الخلفية.\n" +
                "٢. الإعدادات ← التطبيقات ← التشغيل التلقائي: فعّل حِمى.\n" +
                "٣. اقفل حِمى في قائمة التطبيقات الأخيرة.",
            "١. معلومات التطبيق ← البطارية: اختر «بدون قيود» أو أوقف تحسين البطارية لحِمى.\n" +
                "٢. إن وجدت في هاتفك خيار «التشغيل التلقائي» أو «النشاط في الخلفية» فعّله.\n" +
                "٣. اقفل حِمى في قائمة التطبيقات الأخيرة إن أتاح هاتفك ذلك.\n" +
                "٤. تختلف أسماء القوائم بين الهواتف، فابحث عن «حِمى» في الإعدادات."
        )
    }

    private lateinit var store: Store
    private var backAction: (() -> Unit)? = null
    private var current: (() -> Unit)? = null
    private var cachedApps: List<AppItem>? = null
    private var brandSel = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        C.setTheme(store.theme)
        styleBars()
        Scheduler.scheduleAll(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        if (splashDone) showHome() else showSplash()
    }

    override fun onResume() {
        super.onResume()
        current?.invoke()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val b = backAction
        if (b != null) b() else super.onBackPressed()
    }

    // ---------------- الهيكل العام ----------------
    private fun showSplash() {
        current = null
        backAction = null
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(C.BG)
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.addView(img(R.drawable.art_arch, 230, 270))
        root.addView(tv("حِمى", 56f, C.TEXT, true, true, true))
        root.addView(tv("وردك أولًا .. ثم افتح ما تشاء", 16f, C.MUTED, false, true))
        root.addView(img(R.drawable.deco_divider, 160, 24))
        setContentView(root)
        Handler(Looper.getMainLooper()).postDelayed({
            splashDone = true
            if (!isFinishing) showHome()
        }, 1400)
    }

    private fun page(navSel: Int, back: (() -> Unit)?, title: String?): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(16), dp(20), dp(24))
        val sv = ScrollView(this)
        sv.addView(col)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(C.BG)
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        if (navSel >= 0) root.addView(navBar(navSel))
        setContentView(root)
        backAction = back
        if (title != null) col.addView(header(title, if (navSel < 0) back else null))
        return col
    }

    private fun header(title: String, back: (() -> Unit)?): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val arrow = TextView(this)
        arrow.text = if (back != null) "→" else ""
        arrow.textSize = 26f
        arrow.setTextColor(C.PRIMARY_DARK)
        arrow.gravity = Gravity.CENTER
        arrow.layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        if (back != null) arrow.setOnClickListener { back() }
        val t = tv(title, 22f, C.PRIMARY_DARK, true, true, true)
        t.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val sp = View(this)
        sp.layoutParams = LinearLayout.LayoutParams(dp(44), 1)
        row.addView(arrow)
        row.addView(t)
        row.addView(sp)
        return row
    }

    private fun navBar(sel: Int): View {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(C.CARD)
        bar.setPadding(dp(8), dp(6), dp(8), dp(6))
        val items = listOf("🏠" to "الرئيسية", "📱" to "التطبيقات", "⚙️" to "الإعدادات")
        items.forEachIndexed { i, item ->
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER
            cell.setPadding(0, dp(4), 0, dp(4))
            cell.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            val a = TextView(this)
            a.text = item.first
            a.textSize = 22f
            a.gravity = Gravity.CENTER
            a.alpha = if (i == sel) 1f else 0.5f
            val b = TextView(this)
            b.text = item.second
            b.textSize = 12f
            b.gravity = Gravity.CENTER
            b.setTextColor(if (i == sel) C.PRIMARY_DARK else C.MUTED)
            if (i == sel) b.setTypeface(b.typeface, Typeface.BOLD)
            cell.addView(a)
            cell.addView(b)
            cell.setOnClickListener {
                when (i) {
                    0 -> showHome()
                    1 -> showApps()
                    else -> showSettings()
                }
            }
            bar.addView(cell)
        }
        return bar
    }

    private fun chip(text: String, selected: Boolean, onClick: () -> Unit): TextView {
        val c = TextView(this)
        c.text = text
        c.textSize = 14f
        c.gravity = Gravity.CENTER
        c.setPadding(dp(16), dp(8), dp(16), dp(8))
        c.setTextColor(if (selected) C.ON_PRIMARY else C.TEXT)
        c.background = rounded(if (selected) C.PRIMARY else C.SOFT, dp(20).toFloat())
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.marginEnd = dp(8)
        c.layoutParams = lp
        c.setOnClickListener { onClick() }
        return c
    }

    private fun chipsRow(labels: List<String>, selected: Int, onPick: (Int) -> Unit): View {
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        labels.forEachIndexed { i, l -> row.addView(chip(l, i == selected) { onPick(i) }) }
        hs.addView(row)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(12)
        hs.layoutParams = lp
        return hs
    }

    // ---------------- الرئيسية ----------------
    private fun showHome() {
        current = { showHome() }
        val col = page(0, null, null)
        col.addView(tv("حِمى", 38f, C.TEXT, true, true, true))
        col.addView(tv("وردك اليوم .. طريقك للطمأنينة", 14f, C.MUTED, false, true))
        col.addView(img(R.drawable.deco_divider, 140, 22))

        if (!isAccessibilityOn() || !Settings.canDrawOverlays(this)) {
            val w = card()
            w.addView(tv("⚠️ الحجب غير مفعّل بعد. اضغط هنا لإعداد الحماية.", 15f, C.WARN, true))
            w.setOnClickListener { showProtection() }
            col.addView(w)
        }

        val st = store.streak()
        if (st > 0) {
            val pill = TextView(this)
            pill.text = "🔥  ${Cheer.title(st)}"
            pill.textSize = 14f
            pill.setTextColor(C.PRIMARY_DARK)
            pill.gravity = Gravity.CENTER
            pill.setPadding(dp(16), dp(8), dp(16), dp(8))
            pill.background = rounded(C.SOFT, dp(20).toFloat())
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.gravity = Gravity.CENTER_HORIZONTAL
            lp.topMargin = dp(12)
            pill.layoutParams = lp
            col.addView(pill)
        }

        Sections.keys.forEachIndexed { i, k -> col.addView(sectionCard(i, k)) }
    }

    private fun sectionCard(i: Int, k: String): View {
        val n = store.getAdhkar(k).size
        val status = when {
            n == 0 -> "لا توجد أذكار بعد، اضغط ✎ للإضافة"
            store.isDone(k) -> "تم اليوم ✓"
            else -> "$n أذكار  •  من ${Sections.fmt(store.getTime(k))}"
        }
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(16), dp(16), dp(16), dp(16))
        row.background = rounded(C.SEC[i], dp(24).toFloat())
        val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rlp.topMargin = dp(12)
        row.layoutParams = rlp

        val ic = TextView(this)
        ic.text = Sections.emoji(k)
        ic.textSize = 26f
        ic.gravity = Gravity.CENTER
        ic.background = ovalGrad(Sections.c1(k), Sections.c2(k))
        ic.layoutParams = LinearLayout.LayoutParams(dp(58), dp(58))

        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        val tlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tlp.marginStart = dp(14)
        tlp.marginEnd = dp(8)
        texts.layoutParams = tlp
        texts.addView(tv(Sections.title(k), 20f, C.TEXT, true, false, true))
        texts.addView(tv(status, 14f, C.MUTED))

        val edit = TextView(this)
        edit.text = "✎"
        edit.textSize = 24f
        edit.setTextColor(C.MUTED)
        edit.gravity = Gravity.CENTER
        edit.layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        edit.setOnClickListener { showSection(k) }

        row.addView(ic)
        row.addView(texts)
        row.addView(edit)
        row.setOnClickListener {
            if (store.getAdhkar(k).isEmpty()) showSection(k)
            else startActivity(Intent(this, WirdActivity::class.java).putExtra("key", k))
        }
        return row
    }

    // ---------------- إدارة أذكار قسم ----------------
    private fun smallBtn(text: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 14f
        t.setTextColor(C.PRIMARY_DARK)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(8), dp(10), dp(8), dp(10))
        t.background = rounded(C.SOFT, dp(12).toFloat())
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.marginStart = dp(4)
        lp.marginEnd = dp(4)
        t.layoutParams = lp
        t.setOnClickListener { onClick() }
        return t
    }

    private fun showSection(k: String) {
        current = { showSection(k) }
        val col = page(-1, { showHome() }, "إدارة الأذكار")
        col.addView(chipsRow(Sections.keys.map { Sections.short(it) }, Sections.keys.indexOf(k)) { showSection(Sections.keys[it]) })
        col.addView(btn("＋  إضافة ذكر جديد", C.CARD, C.PRIMARY_DARK) { editDialog(k, -1) })

        val list = store.getAdhkar(k)
        if (list.isEmpty()) {
            col.addView(tv("لا توجد أذكار في هذا القسم بعد.", 15f, C.MUTED, false, true))
        }
        list.forEachIndexed { i, d ->
            val c = card()
            c.addView(tv(d.text, 19f, C.TEXT, true, false, true))
            c.addView(tv("${d.count} مرة", 13f, C.MUTED))
            val actions = LinearLayout(this)
            actions.orientation = LinearLayout.HORIZONTAL
            val alp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            alp.topMargin = dp(10)
            actions.layoutParams = alp
            actions.addView(smallBtn("تعديل") { editDialog(k, i) })
            actions.addView(smallBtn("حذف") {
                AlertDialog.Builder(this)
                    .setMessage("حذف هذا الذكر؟")
                    .setPositiveButton("حذف") { _, _ ->
                        list.removeAt(i)
                        store.saveAdhkar(k, list)
                        store.clearProgress(k)
                        showSection(k)
                    }
                    .setNegativeButton("إلغاء", null)
                    .show()
            })
            actions.addView(smallBtn("▲") {
                if (i > 0) {
                    Collections.swap(list, i, i - 1)
                    store.saveAdhkar(k, list)
                    store.clearProgress(k)
                    showSection(k)
                }
            })
            actions.addView(smallBtn("▼") {
                if (i < list.size - 1) {
                    Collections.swap(list, i, i + 1)
                    store.saveAdhkar(k, list)
                    store.clearProgress(k)
                    showSection(k)
                }
            })
            c.addView(actions)
            col.addView(c)
        }
        if (list.isNotEmpty()) {
            col.addView(btn("▶  ابدأ الورد", C.PRIMARY) {
                startActivity(Intent(this, WirdActivity::class.java).putExtra("key", k))
            })
        }
    }

    private fun editDialog(k: String, index: Int) {
        val list = store.getAdhkar(k)
        val edit = if (index >= 0) list[index] else null
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(10), dp(20), 0)
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val t = EditText(this)
        t.hint = "نص الذكر"
        t.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        t.minLines = 2
        t.setText(edit?.text ?: "")
        val n = EditText(this)
        n.hint = "عدد التكرار"
        n.inputType = InputType.TYPE_CLASS_NUMBER
        n.setText((edit?.count ?: 1).toString())
        box.addView(t)
        box.addView(n)
        AlertDialog.Builder(this)
            .setTitle(if (edit == null) "إضافة ذكر" else "تعديل الذكر")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val text = t.text.toString().trim()
                val c = (n.text.toString().toIntOrNull() ?: 1).coerceAtLeast(1)
                if (text.isNotEmpty()) {
                    if (edit != null) list[index] = Dhikr(text, c) else list.add(Dhikr(text, c))
                    store.saveAdhkar(k, list)
                    store.clearProgress(k)
                    showSection(k)
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ---------------- التطبيقات المحجوبة ----------------
    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(q, 0)
            .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    private fun switchTint(sw: Switch) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(C.PRIMARY, C.MUTED))
        sw.trackTintList = ColorStateList(states, intArrayOf(C.BEAD_OFF, C.BORDER))
    }

    private fun appRow(a: AppItem, chosen: MutableSet<String>): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(14), dp(10), dp(14), dp(10))
        row.background = rounded(C.CARD, dp(16).toFloat())
        val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rlp.topMargin = dp(8)
        row.layoutParams = rlp
        val ic = ImageView(this)
        ic.setImageDrawable(a.icon)
        ic.layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
        val name = TextView(this)
        name.text = a.label
        name.textSize = 17f
        name.setTextColor(C.TEXT)
        val nlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        nlp.marginStart = dp(12)
        nlp.marginEnd = dp(8)
        name.layoutParams = nlp
        val sw = Switch(this)
        switchTint(sw)
        sw.isChecked = a.pkg in chosen
        sw.setOnCheckedChangeListener { _, on ->
            if (on) chosen.add(a.pkg) else chosen.remove(a.pkg)
            store.setBlockedApps(chosen)
        }
        row.addView(ic)
        row.addView(name)
        row.addView(sw)
        return row
    }

    private fun showApps() {
        current = { showApps() }
        val col = page(1, { showHome() }, "التطبيقات المحجوبة")
        col.addView(tv("اختر التطبيقات التي تُحجب حتى تكمل الورد. لا حدّ لعددها.", 14f, C.MUTED, false, true))
        val search = EditText(this)
        search.hint = "ابحث عن تطبيق..."
        search.textSize = 16f
        search.setTextColor(C.TEXT)
        search.setHintTextColor(C.MUTED)
        search.isSingleLine = true
        search.setPadding(dp(16), dp(12), dp(16), dp(12))
        search.background = rounded(C.CARD, dp(20).toFloat())
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.topMargin = dp(12)
        search.layoutParams = slp
        col.addView(search)
        val listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        col.addView(listBox)

        val apps = cachedApps ?: loadApps().also { cachedApps = it }
        val chosen = store.blockedApps()
        fun render(q: String) {
            listBox.removeAllViews()
            for (a in apps) {
                if (q.isNotEmpty() && !a.label.contains(q, ignoreCase = true)) continue
                listBox.addView(appRow(a, chosen))
            }
        }
        render("")
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                render(s?.toString()?.trim() ?: "")
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        col.addView(btn("حفظ") {
            Toast.makeText(this, "تم الحفظ", Toast.LENGTH_SHORT).show()
            showHome()
        })
    }

    // ---------------- الإعدادات ----------------
    private fun showSettings() {
        current = { showSettings() }
        val col = page(2, { showHome() }, "الإعدادات")

        val sc = card()
        val sw = Switch(this)
        sw.text = "تفعيل حجب التطبيقات"
        sw.textSize = 18f
        sw.setTextColor(C.TEXT)
        switchTint(sw)
        sw.isChecked = store.blockingEnabled
        sw.setOnCheckedChangeListener { _, v -> store.blockingEnabled = v }
        sc.addView(sw)
        col.addView(sc)

        col.addView(tv("أوقات الأذكار", 18f, C.PRIMARY_DARK, true, false, true))
        for (k in Sections.keys) {
            val t = store.getTime(k)
            col.addView(btn("${Sections.emoji(k)}  ${Sections.title(k)}:  ${Sections.fmt(t)}", C.CARD, C.PRIMARY_DARK) {
                TimePickerDialog(this, { _, h, m ->
                    store.setTime(k, h * 60 + m)
                    Scheduler.schedule(this, k, h * 60 + m)
                    showSettings()
                }, t / 60, t % 60, true).show()
            })
        }

        col.addView(tv("المظهر", 18f, C.PRIMARY_DARK, true, false, true))
        col.addView(chipsRow(C.THEME_NAMES, C.themeIndex) {
            store.theme = it
            C.setTheme(it)
            styleBars()
            showSettings()
        })

        col.addView(tv("الحماية", 18f, C.PRIMARY_DARK, true, false, true))
        col.addView(btn("🛡️  إعداد الحماية والأذونات") { showProtection() })
        col.addView(tv("حِمى يعمل بدون إنترنت، ولا يجمع أي بيانات، وكل ما تكتبه محفوظ على هاتفك فقط.", 13f, C.MUTED, false, true))
    }

    // ---------------- إعداد الحماية ----------------
    private fun isAccessibilityOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(this, BlockerService::class.java)
        return s.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    private fun detectBrand(): Int {
        val m = (Build.MANUFACTURER + " " + Build.BRAND).lowercase()
        return when {
            "xiaomi" in m || "redmi" in m || "poco" in m -> 0
            "samsung" in m -> 1
            "huawei" in m || "honor" in m -> 2
            "oppo" in m || "realme" in m || "oneplus" in m -> 3
            "vivo" in m || "iqoo" in m -> 4
            else -> 5
        }
    }

    private fun permCard(col: LinearLayout, title: String, why: String, on: Boolean, actionText: String, action: () -> Unit) {
        val c = card()
        c.addView(tv(title, 17f, C.PRIMARY_DARK, true, false, true))
        c.addView(tv(why, 14f, C.TEXT))
        c.addView(tv(if (on) "الحالة: مفعّل ✓" else "الحالة: غير مفعّل", 14f, if (on) C.GREEN else C.WARN, true))
        c.addView(btn(actionText, C.PRIMARY) { action() })
        col.addView(c)
    }

    private fun showProtection() {
        current = { showProtection() }
        if (brandSel < 0) brandSel = detectBrand()
        val col = page(-1, { showSettings() }, "إعداد الحماية")
        col.addView(tv("لمنع فتح التطبيقات قبل إكمال الورد، تحتاج حِمى إلى الصلاحيات التالية:", 14f, C.MUTED, false, true))

        permCard(
            col, "١. خدمة إمكانية الوصول",
            "تخبر حِمى بأن تطبيقًا محجوبًا فُتح، فتعرض لك الورد بدل التطبيق. لا تقرأ أي محتوى ولا ترسل بيانات.\n" +
                "إن كان الخيار رماديًا: معلومات التطبيق ← ⋮ ← «السماح بالإعدادات المقيّدة»، ثم ارجع وفعّلها.",
            isAccessibilityOn(), "فتح إعدادات إمكانية الوصول"
        ) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        permCard(
            col, "٢. الظهور فوق التطبيقات",
            "يسمح لحِمى بالظهور فورًا فوق التطبيق المحجوب.",
            Settings.canDrawOverlays(this), "فتح الإعدادات"
        ) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        permCard(
            col, "٣. الإشعارات",
            "لتنبيهك عند حلول وقت الورد وعند محاولة فتح تطبيق محجوب.",
            nm.areNotificationsEnabled(), "السماح بالإشعارات"
        ) {
            startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            )
        }

        col.addView(tv("حتى لا يوقف النظام حِمى في الخلفية", 17f, C.PRIMARY_DARK, true, false, true))
        col.addView(tv("اختر نوع هاتفك:", 14f, C.MUTED))
        col.addView(chipsRow(BRANDS, brandSel) {
            brandSel = it
            showProtection()
        })
        val g = card()
        g.addView(tv(GUIDE[brandSel], 14f, C.TEXT))
        g.addView(tv("قد تختلف أسماء القوائم قليلًا حسب إصدار هاتفك.", 12f, C.MUTED))
        col.addView(g)
        col.addView(btn("فتح معلومات التطبيق", C.CARD, C.PRIMARY_DARK) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        col.addView(btn("فتح إعدادات البطارية", C.CARD, C.PRIMARY_DARK) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        val lim = card()
        lim.addView(tv("ما الذي تستطيع حِمى منعه فعليًا؟", 16f, C.PRIMARY_DARK, true, false, true))
        lim.addView(
            tv(
                "تحجب التطبيقات المختارة عند فتحها ما دام الورد غير مكتمل، لكن الحماية ليست مطلقة: " +
                    "يمكن إيقاف خدمة إمكانية الوصول من إعدادات الهاتف، وأندرويد لا يسمح لتطبيق عادي بمنع ذلك. " +
                    "الحجب يعتمد على التزامك أكثر من كونه قفلًا لا يُكسر.",
                14f, C.TEXT
            )
        )
        col.addView(lim)
    }
}
