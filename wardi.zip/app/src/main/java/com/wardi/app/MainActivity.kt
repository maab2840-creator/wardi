package com.wardi.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.util.Collections

data class AppItem(val pkg: String, val label: String, val icon: Drawable)

class MainActivity : Activity() {
    private lateinit var store: Store
    private var backAction: (() -> Unit)? = null
    private var current: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        Scheduler.scheduleAll(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        showHome()
    }

    override fun onResume() {
        super.onResume()
        current?.invoke()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val b = backAction
        if (b != null) b() else super.onBackPressed()
    }

    private fun page(title: String, back: (() -> Unit)?): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(24), dp(20), dp(32))
        val sv = ScrollView(this)
        sv.setBackgroundColor(C.BG)
        sv.layoutDirection = View.LAYOUT_DIRECTION_RTL
        sv.addView(col)
        setContentView(sv)
        backAction = back
        col.addView(tv(title, 26f, C.PRIMARY_DARK, true, true))
        return col
    }

    // ---------------- الرئيسية ----------------
    private fun showHome() {
        current = { showHome() }
        val col = page("وردِي 🤍", null)

        if (!isAccessibilityOn() || !Settings.canDrawOverlays(this)) {
            val w = card()
            w.addView(tv("⚠️ الحجب غير مفعّل بعد. اضغطي هنا لتفعيل الأذونات.", 15f, C.WARN, true))
            w.setOnClickListener { showSettings() }
            col.addView(w)
        }

        col.addView(tv("اختاري القسم", 16f, C.MUTED, false, true))
        for (k in Sections.keys) {
            val n = store.getAdhkar(k).size
            val status = when {
                n == 0 -> "لم تُضَف أذكار بعد"
                store.isDone(k) -> "تم اليوم ✓"
                else -> "$n من الأذكار  •  الوقت ${Sections.fmt(store.getTime(k))}"
            }
            val c = card()
            c.addView(tv("${Sections.emoji(k)}  ${Sections.title(k)}", 22f, C.PRIMARY_DARK, true))
            c.addView(tv(status, 14f, C.MUTED))
            c.setOnClickListener { showSection(k) }
            col.addView(c)
        }
        col.addView(btn("📱 التطبيقات المحجوبة") { showApps() })
        col.addView(btn("⚙️ الإعدادات والأذونات", Color.WHITE, C.PRIMARY_DARK) { showSettings() })
    }

    // ---------------- قسم ----------------
    private fun smallBtn(text: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 14f
        t.setTextColor(C.PRIMARY_DARK)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(8), dp(10), dp(8), dp(10))
        t.background = rounded(C.SOFT, dp(10).toFloat())
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.marginStart = dp(4)
        lp.marginEnd = dp(4)
        t.layoutParams = lp
        t.setOnClickListener { onClick() }
        return t
    }

    private fun showSection(k: String) {
        current = { showSection(k) }
        val col = page("${Sections.emoji(k)}  ${Sections.title(k)}") { showHome() }
        val list = store.getAdhkar(k)
        if (list.isEmpty()) {
            col.addView(tv("لا توجد أذكار بعد. اضغطي «إضافة ذكر».", 16f, C.MUTED, false, true))
        }
        list.forEachIndexed { i, d ->
            val c = card()
            c.addView(tv(d.text, 20f, C.TEXT))
            c.addView(tv("التكرار: ${d.count}", 14f, C.MUTED))
            val actions = LinearLayout(this)
            actions.orientation = LinearLayout.HORIZONTAL
            val alp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            alp.topMargin = dp(10)
            actions.layoutParams = alp
            actions.addView(smallBtn("تعديل") { editDialog(k, i) })
            actions.addView(smallBtn("حذف") {
                AlertDialog.Builder(this)
                    .setMessage("حذف هذا الذكر؟")
                    .setPositiveButton("حذف") { _, _ ->
                        list.removeAt(i)
                        store.saveAdhkar(k, list)
                        store.clearProgress(k)
                        showSection(k)
                    }
                    .setNegativeButton("إلغاء", null)
                    .show()
            })
            actions.addView(smallBtn("▲") {
                if (i > 0) {
                    Collections.swap(list, i, i - 1)
                    store.saveAdhkar(k, list)
                    store.clearProgress(k)
                    showSection(k)
                }
            })
            actions.addView(smallBtn("▼") {
                if (i < list.size - 1) {
                    Collections.swap(list, i, i + 1)
                    store.saveAdhkar(k, list)
                    store.clearProgress(k)
                    showSection(k)
                }
            })
            c.addView(actions)
            col.addView(c)
        }
        col.addView(btn("➕ إضافة ذكر") { editDialog(k, -1) })
        if (list.isNotEmpty()) {
            col.addView(btn("▶️ ابدأ الورد", C.GREEN) {
                startActivity(Intent(this, WirdActivity::class.java).putExtra("key", k))
            })
        }
    }

    private fun editDialog(k: String, index: Int) {
        val list = store.getAdhkar(k)
        val edit = if (index >= 0) list[index] else null
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(10), dp(20), 0)
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val t = EditText(this)
        t.hint = "نص الذكر"
        t.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        t.minLines = 2
        t.setText(edit?.text ?: "")
        val n = EditText(this)
        n.hint = "عدد التكرار"
        n.inputType = InputType.TYPE_CLASS_NUMBER
        n.setText((edit?.count ?: 1).toString())
        box.addView(t)
        box.addView(n)
        AlertDialog.Builder(this)
            .setTitle(if (edit == null) "إضافة ذكر" else "تعديل الذكر")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val text = t.text.toString().trim()
                val c = (n.text.toString().toIntOrNull() ?: 1).coerceAtLeast(1)
                if (text.isNotEmpty()) {
                    if (edit != null) list[index] = Dhikr(text, c) else list.add(Dhikr(text, c))
                    store.saveAdhkar(k, list)
                    store.clearProgress(k)
                    showSection(k)
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ---------------- التطبيقات المحجوبة ----------------
    private fun showApps() {
        current = { showApps() }
        val col = page("التطبيقات المحجوبة") { showHome() }
        col.addView(tv("اختاري التطبيقات التي تُحجب حتى تكملي الورد. لا يوجد حدّ لعددها.", 15f, C.MUTED, false, true))
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
        val chosen = store.blockedApps()
        for (a in apps) {
            val cb = CheckBox(this)
            cb.text = a.label
            cb.textSize = 18f
            cb.setTextColor(C.TEXT)
            cb.isChecked = a.pkg in chosen
            a.icon.setBounds(0, 0, dp(40), dp(40))
            cb.setCompoundDrawablesRelative(a.icon, null, null, null)
            cb.compoundDrawablePadding = dp(12)
            cb.setPadding(0, dp(8), 0, dp(8))
            cb.setOnCheckedChangeListener { _, on ->
                val s = store.blockedApps()
                if (on) s.add(a.pkg) else s.remove(a.pkg)
                store.setBlockedApps(s)
            }
            col.addView(cb)
        }
    }

    // ---------------- الإعدادات ----------------
    private fun isAccessibilityOn(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return enabled.contains("$packageName/${BlockerService::class.java.name}")
    }

    private fun permCard(col: LinearLayout, title: String, why: String, on: Boolean?, actionText: String, action: () -> Unit) {
        val c = card()
        c.addView(tv(title, 18f, C.PRIMARY_DARK, true))
        c.addView(tv(why, 14f, C.TEXT))
        if (on != null) {
            c.addView(tv(if (on) "الحالة: مفعّل ✓" else "الحالة: غير مفعّل", 14f, if (on) C.GREEN else C.WARN, true))
        }
        c.addView(btn(actionText, C.PRIMARY) { action() })
        col.addView(c)
    }

    private fun showSettings() {
        current = { showSettings() }
        val col = page("الإعدادات والأذونات") { showHome() }

        val sc = card()
        val sw = Switch(this)
        sw.text = "تفعيل حجب التطبيقات"
        sw.textSize = 18f
        sw.isChecked = store.blockingEnabled
        sw.setOnCheckedChangeListener { _, v -> store.blockingEnabled = v }
        sc.addView(sw)
        col.addView(sc)

        col.addView(tv("أوقات الأذكار (اضغطي لتغيير الوقت)", 18f, C.PRIMARY_DARK, true))
        for (k in Sections.keys) {
            val t = store.getTime(k)
            col.addView(btn("${Sections.emoji(k)} ${Sections.title(k)}:  ${Sections.fmt(t)}", Color.WHITE, C.PRIMARY_DARK) {
                TimePickerDialog(this, { _, h, m ->
                    store.setTime(k, h * 60 + m)
                    Scheduler.schedule(this, k, h * 60 + m)
                    showSettings()
                }, t / 60, t % 60, true).show()
            })
        }

        col.addView(tv("الأذونات المطلوبة", 18f, C.PRIMARY_DARK, true))

        permCard(
            col, "١. خدمة الإتاحة (Accessibility)",
            "هي التي تُخبر وردِي بأن تطبيقًا محجوبًا فُتح، فتعرض لكِ الورد بدل التطبيق. لا تقرأ أي محتوى ولا ترسل بيانات. " +
                "خطوات التفعيل: افتحي الإعدادات ← التطبيقات المثبّتة ← وردِي ← شغّليها.\n" +
                "إن كان الخيار رماديًا: افتحي «معلومات التطبيق» ← النقاط الثلاث ⋮ ← «السماح بالإعدادات المقيّدة»، ثم ارجعي وفعّليها.",
            isAccessibilityOn(), "فتح إعدادات الإتاحة"
        ) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        permCard(
            col, "٢. العرض فوق التطبيقات",
            "يسمح لوردِي بالظهور فوراً فوق التطبيق المحجوب. شغّلي الخيار لوردِي.",
            Settings.canDrawOverlays(this), "فتح الإعدادات"
        ) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        permCard(
            col, "٣. الإشعارات",
            "لتنبيهكِ عند حلول وقت الورد وعند محاولة فتح تطبيق محجوب.",
            nm.areNotificationsEnabled(), "السماح بالإشعارات"
        ) {
            startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            )
        }

        permCard(
            col, "٤. إعدادات هواتف شاومي / ريدمي",
            "حتى لا يوقف النظام وردِي في الخلفية: من معلومات التطبيق فعّلي «التشغيل التلقائي» (Autostart)، " +
                "واجعلي توفير البطارية «بدون قيود»، وفي «أذونات أخرى» فعّلي «عرض النوافذ المنبثقة أثناء التشغيل في الخلفية». " +
                "ويُستحسن قفل وردِي في قائمة التطبيقات الأخيرة.",
            null, "فتح معلومات التطبيق"
        ) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }

        val lim = card()
        lim.addView(tv("ما الذي يستطيع وردِي منعه فعليًا؟", 17f, C.PRIMARY_DARK, true))
        lim.addView(
            tv(
                "يحجب التطبيقات المختارة عند فتحها ما دام الورد غير مكتمل، لكن الحماية ليست مطلقة: " +
                    "يمكن إيقاف خدمة الإتاحة من إعدادات الهاتف، وأندرويد لا يسمح لتطبيق عادي بمنع ذلك. " +
                    "الحجب مبني على الالتزام الشخصي وليس قفلًا لا يُكسر.",
                14f, C.TEXT
            )
        )
        col.addView(lim)
    }
}
