package com.mustarah.app

import android.Manifest
import androidx.fragment.app.FragmentActivity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.util.UUID

class MainActivity : FragmentActivity() {
    private lateinit var store: Store
    private var backAction: (() -> Unit)? = null
    private var current: (() -> Unit)? = null
    private var unlocked = false
    private var pendingPhotoEntry: ((String) -> Unit)? = null
    private var recorder: MediaRecorder? = null
    private var recordingPath: String? = null
    private var player: MediaPlayer? = null

    private val pickPhoto = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                val dir = File(filesDir, "media"); dir.mkdirs()
                val out = File(dir, "${UUID.randomUUID()}.jpg")
                contentResolver.openInputStream(uri)?.use { input -> out.outputStream().use { o -> input.copyTo(o) } }
                pendingPhotoEntry?.invoke(out.absolutePath)
            } catch (e: Exception) {}
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this); C.set(store.theme); styleBars()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        if (store.hasLock && !unlocked) showLock() else { unlocked = true; showHome() }
    }

    override fun onResume() { super.onResume(); if (unlocked) current?.invoke() }

    @Suppress("DEPRECATION")
    override fun onBackPressed() { val b = backAction; if (b != null) b() else super.onBackPressed() }

    @Suppress("DEPRECATION")
    private fun styleBars() {
        window.statusBarColor = C.BG; window.navigationBarColor = C.BG
        val d = window.decorView; var f = d.systemUiVisibility
        f = if (C.idx == 1 || C.idx == 4) f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
        else f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        d.systemUiVisibility = f
    }

    // ---------------- القفل ----------------
    private fun showLock() {
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL; col.gravity = Gravity.CENTER
        col.setBackgroundColor(C.BG); col.setPadding(dp(28), dp(28), dp(28), dp(28)); col.layoutDirection = View.LAYOUT_DIRECTION_RTL
        col.addView(tv("🔒", 44f, C.PRIMARY, true, true))
        col.addView(tv("اليوميات الخاصة", 22f, C.TEXT, true, true))
        col.addView(tv("أدخل رمز الدخول", 14f, C.MUTED, false, true))
        val input = EditText(this); input.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIANT_PASSWORD
        input.gravity = Gravity.CENTER; input.textSize = 26f; input.setTextColor(C.TEXT)
        input.setPadding(dp(16), dp(14), dp(16), dp(14)); input.background = rounded(C.CARD, dp(16).toFloat())
        val ilp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); ilp.topMargin = dp(20)
        input.layoutParams = ilp
        col.addView(input)
        val err = tv("", 13f, C.WARN, false, true); col.addView(err)
        col.addView(btn("دخول") {
            if (store.pin.isNotEmpty() && input.text.toString() == store.pin) { unlocked = true; showHome() }
            else err.text = "الرمز غير صحيح"
        })
        if (store.biometricOn) {
            col.addView(btn("استخدام البصمة", C.CARD, C.PRIMARY_DARK) { tryBiometric() })
        }
        setContentView(col)
        backAction = { moveTaskToBack(true) }
        if (store.biometricOn) tryBiometric()
    }

    private fun tryBiometric() {
        val bm = BiometricManager.from(this)
        if (bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) != BiometricManager.BIOMETRIC_SUCCESS) return
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                unlocked = true; runOnUiThread { showHome() }
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder().setTitle("مُستراح").setSubtitle("استخدم بصمتك للدخول")
            .setNegativeButtonText("إلغاء").build()
        prompt.authenticate(info)
    }

    // ---------------- هيكل الصفحات ----------------
    private fun page(navSel: Int, back: (() -> Unit)?, title: String?): LinearLayout {
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(18), dp(20), dp(24))
        val sv = ScrollView(this); sv.addView(col)
        val root = LinearLayout(this); root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(C.BG); root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        if (navSel >= 0) root.addView(navBar(navSel))
        setContentView(root); backAction = back
        if (title != null) col.addView(header(title, if (navSel < 0) back else null))
        return col
    }

    private fun header(title: String, back: (() -> Unit)?): View {
        val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
        val arrow = TextView(this); arrow.text = if (back != null) "→" else ""; arrow.textSize = 26f
        arrow.setTextColor(C.PRIMARY_DARK); arrow.gravity = Gravity.CENTER; arrow.layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        if (back != null) arrow.setOnClickListener { back() }
        val t = tv(title, 22f, C.PRIMARY_DARK, true, true)
        t.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val sp = View(this); sp.layoutParams = LinearLayout.LayoutParams(dp(44), 1)
        row.addView(arrow); row.addView(t); row.addView(sp); return row
    }

    private fun navBar(sel: Int): View {
        val bar = LinearLayout(this); bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(C.CARD); bar.setPadding(dp(8), dp(6), dp(8), dp(6))
        val items = listOf("🏠" to "الرئيسية", "📔" to "يومياتي", "✅" to "مهامي", "🌱" to "عاداتي", "⚙️" to "الإعدادات")
        items.forEachIndexed { i, item ->
            val cell = LinearLayout(this); cell.orientation = LinearLayout.VERTICAL; cell.gravity = Gravity.CENTER
            cell.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            val a = TextView(this); a.text = item.first; a.textSize = 20f; a.gravity = Gravity.CENTER; a.alpha = if (i == sel) 1f else 0.5f
            val b = TextView(this); b.text = item.second; b.textSize = 11f; b.gravity = Gravity.CENTER
            b.setTextColor(if (i == sel) C.PRIMARY_DARK else C.MUTED); if (i == sel) b.setTypeface(b.typeface, Typeface.BOLD)
            cell.addView(a); cell.addView(b)
            cell.setOnClickListener { when (i) { 0 -> showHome(); 1 -> showDiaryGate(); 2 -> showTasks(); 3 -> showHabits(); else -> showSettings() } }
            bar.addView(cell)
        }
        return bar
    }

    private fun chip(text: String, selected: Boolean, onClick: () -> Unit): TextView {
        val c = TextView(this); c.text = text; c.textSize = 14f; c.gravity = Gravity.CENTER
        c.setPadding(dp(16), dp(8), dp(16), dp(8)); c.setTextColor(if (selected) C.ON_PRIMARY else C.TEXT)
        c.background = rounded(if (selected) C.PRIMARY else C.SOFT, dp(20).toFloat())
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT); lp.marginEnd = dp(8)
        c.layoutParams = lp; c.setOnClickListener { onClick() }; return c
    }

    private fun greeting(): String {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return when { h < 5 -> "ليلة سعيدة 🌙"; h < 12 -> "صباح الخير ☀️"; h < 17 -> "نهارك سعيد 🌿"; else -> "مساء الخير 🌙" }
    }

    // ---------------- الرئيسية ----------------
    private fun showHome() {
        current = { showHome() }
        val col = page(0, null, null)
        col.addView(tv(greeting(), 26f, C.TEXT, true, true))
        col.addView(tv("كيف كان يومك اليوم؟", 14f, C.MUTED, false, true))

        val rev = store.review(store.today())
        val (done, total) = store.todayProgress()
        val pct = if (total == 0) 0 else done * 100 / total

        val top = card()
        val row1 = LinearLayout(this); row1.orientation = LinearLayout.HORIZONTAL
        row1.addView(tv(Fmt.human.format(java.util.Date()), 15f, C.MUTED).also { it.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
        if (rev != null) row1.addView(tv(moodEmoji(rev.mood) + " " + moodLabel(rev.mood), 15f, C.TEXT, true))
        top.addView(row1)
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100; bar.progress = pct
        bar.progressTintList = android.content.res.ColorStateList.valueOf(C.PRIMARY)
        val blp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8)); blp.topMargin = dp(10); bar.layoutParams = blp
        top.addView(bar)
        top.addView(tv("$done / $total مهام • $pct% تقدّم اليوم", 13f, C.MUTED))
        col.addView(top)

        col.addView(tv("وصول سريع", 15f, C.MUTED, false, true))
        val grid = LinearLayout(this); grid.orientation = LinearLayout.HORIZONTAL
        val glp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); glp.topMargin = dp(8)
        grid.layoutParams = glp
        fun quick(emoji: String, label: String, action: () -> Unit): View {
            val c = LinearLayout(this); c.orientation = LinearLayout.VERTICAL; c.gravity = Gravity.CENTER
            c.setPadding(dp(8), dp(14), dp(8), dp(14)); c.background = rounded(C.CARD, dp(16).toFloat())
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); lp.marginStart = dp(4); lp.marginEnd = dp(4)
            c.layoutParams = lp; c.addView(tv(emoji, 22f, C.TEXT, false, true)); c.addView(tv(label, 12f, C.TEXT, false, true))
            c.setOnClickListener { action() }; return c
        }
        grid.addView(quick("📔", "يومياتي") { showDiaryGate() })
        grid.addView(quick("✅", "مهامي") { showTasks() })
        grid.addView(quick("🌱", "عاداتي") { showHabits() })
        grid.addView(quick("⭐", "مراجعة اليوم") { showReview() })
        col.addView(grid)

        col.addView(tv("مهام اليوم", 16f, C.PRIMARY_DARK, true, false))
        val tasks = store.tasksForToday()
        if (tasks.isEmpty()) col.addView(tv("لا توجد مهام بعد. أضيفيها من «مهامي».", 14f, C.MUTED))
        for (t in tasks.take(5)) col.addView(taskRow(t) { toggleTask(t) })
    }

    private fun moodEmoji(m: Int) = listOf("😢", "😕", "😐", "😊", "😄").getOrElse(m - 1) { "😐" }
    private fun moodLabel(m: Int) = listOf("سيئ", "متوسط", "عادي", "جيد", "ممتاز").getOrElse(m - 1) { "عادي" }

    // ---------------- اليوميات ----------------
    private fun showDiaryGate() {
        if (!store.hasLock) { showDiaryList(); return }
        current = { showDiaryGate() }
        val col = page(1, { showHome() }, null)
        col.addView(tv("🔒", 40f, C.PRIMARY, true, true))
        col.addView(tv("اليوميات الخاصة", 20f, C.TEXT, true, true))
        col.addView(btn("فتح اليوميات") { showDiaryList() })
    }

    private fun showDiaryList() {
        current = { showDiaryList() }
        val col = page(1, { showHome() }, "يومياتي")
        col.addView(btn("＋ إضافة يومية جديدة") { showDiaryAdd(null) })
        val list = store.diaryList()
        if (list.isEmpty()) col.addView(tv("لا توجد يوميات بعد.", 14f, C.MUTED, false, true))
        var lastDay = ""
        for (e in list) {
            if (e.dateKey != lastDay) { lastDay = e.dateKey; col.addView(tv(e.dateKey, 14f, C.MUTED, true)) }
            val c = card()
            c.addView(tv(Fmt.time.format(java.util.Date(e.time)), 12f, C.MUTED))
            if (e.text.isNotEmpty()) c.addView(tv(e.text, 16f, C.TEXT))
            if (e.photoPath != null) c.addView(photoThumb(e.photoPath!!))
            if (e.audioPath != null) c.addView(audioRow(e.audioPath!!))
            val actions = LinearLayout(this); actions.orientation = LinearLayout.HORIZONTAL
            val alp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); alp.topMargin = dp(8)
            actions.layoutParams = alp
            actions.addView(smallBtn("تعديل") { showDiaryAdd(e) })
            actions.addView(smallBtn("حذف") {
                AlertDialog.Builder(this).setMessage("حذف هذه اليومية؟")
                    .setPositiveButton("حذف") { _, _ -> val l = store.diaryList(); l.removeAll { it.id == e.id }; store.saveDiary(l); showDiaryList() }
                    .setNegativeButton("إلغاء", null).show()
            })
            c.addView(actions)
            col.addView(c)
        }
    }

    private fun smallBtn(text: String, onClick: () -> Unit): TextView {
        val t = TextView(this); t.text = text; t.textSize = 14f; t.setTextColor(C.PRIMARY_DARK); t.gravity = Gravity.CENTER
        t.setPadding(dp(8), dp(10), dp(8), dp(10)); t.background = rounded(C.SOFT, dp(12).toFloat())
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); lp.marginStart = dp(4); lp.marginEnd = dp(4)
        t.layoutParams = lp; t.setOnClickListener { onClick() }; return t
    }

    private fun photoThumb(path: String): View {
        val iv = ImageView(this)
        try { iv.setImageBitmap(android.graphics.BitmapFactory.decodeFile(path)) } catch (e: Exception) {}
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(160)); lp.topMargin = dp(8)
        iv.layoutParams = lp; iv.background = rounded(C.SOFT, dp(12).toFloat()); iv.clipToOutline = true
        return iv
    }

    private fun audioRow(path: String): View {
        val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(12), dp(10), dp(12), dp(10)); row.background = rounded(C.SOFT, dp(14).toFloat())
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); lp.topMargin = dp(8)
        row.layoutParams = lp
        row.addView(tv("🎙️ تسجيل صوتي", 15f, C.TEXT).also { it.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
        val play = tv("▶ تشغيل", 14f, C.PRIMARY_DARK, true)
        play.setOnClickListener {
            try {
                player?.release()
                player = MediaPlayer().apply { setDataSource(path); prepare(); start() }
            } catch (e: Exception) {}
        }
        row.addView(play); return row
    }

    private fun showDiaryAdd(edit: DiaryEntry?) {
        current = { showDiaryAdd(edit) }
        val col = page(-1, { showDiaryList() }, if (edit == null) "يومية جديدة" else "تعديل اليومية")
        var photoPath = edit?.photoPath; var audioPath = edit?.audioPath
        val text = EditText(this); text.hint = "اكتب ما يدور في ذهنك..."; text.setText(edit?.text ?: "")
        text.minLines = 5; text.gravity = Gravity.TOP or Gravity.START
        text.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        text.setPadding(dp(14), dp(14), dp(14), dp(14)); text.background = rounded(C.CARD, dp(16).toFloat())
        val tlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); tlp.topMargin = dp(10)
        text.layoutParams = tlp
        col.addView(text)

        val mediaBox = LinearLayout(this); mediaBox.orientation = LinearLayout.VERTICAL
        fun refreshMedia() {
            mediaBox.removeAllViews()
            photoPath?.let { mediaBox.addView(photoThumb(it)) }
            audioPath?.let { mediaBox.addView(audioRow(it)) }
        }
        refreshMedia(); col.addView(mediaBox)

        val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL
        val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); rlp.topMargin = dp(10)
        row.layoutParams = rlp
        row.addView(smallBtn("📷 صورة") { pendingPhotoEntry = { p -> photoPath = p; refreshMedia() }; pickPhoto.launch("image/*") })
        val recBtn = smallBtn("🎙️ تسجيل", {})
        recBtn.setOnClickListener {
            if (recorder == null) {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2); return@setOnClickListener
                }
                val dir = File(filesDir, "media"); dir.mkdirs()
                val out = File(dir, "${UUID.randomUUID()}.m4a"); recordingPath = out.absolutePath
                recorder = MediaRecorder().apply {
                    setAudioSource(MediaRecorder.AudioSource.MIC); setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                    setAudioEncoder(MediaRecorder.AudioEncoder.AAC); setOutputFile(out.absolutePath)
                    try { prepare(); start() } catch (e: Exception) {}
                }
                recBtn.text = "⏹ إيقاف"
            } else {
                try { recorder?.stop() } catch (e: Exception) {}
                recorder?.release(); recorder = null
                audioPath = recordingPath; recBtn.text = "🎙️ تسجيل"; refreshMedia()
            }
        }
        row.addView(recBtn)
        col.addView(row)

        col.addView(btn("حفظ") {
            val list = store.diaryList()
            if (edit == null) {
                list.add(0, DiaryEntry(UUID.randomUUID().toString(), store.today(), System.currentTimeMillis(), text.text.toString(), photoPath, audioPath))
            } else {
                val idx = list.indexOfFirst { it.id == edit.id }
                if (idx >= 0) list[idx] = DiaryEntry(edit.id, edit.dateKey, edit.time, text.text.toString(), photoPath, audioPath)
            }
            store.saveDiary(list); showDiaryList()
        })
    }

    // ---------------- المهام ----------------
    private fun taskRow(t: Task, onToggle: () -> Unit): View {
        val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(14), dp(12), dp(14), dp(12))
        val prColor = when (t.priority) { 2 -> C.WARN; 1 -> C.GOLD; else -> C.MUTED }
        row.background = rounded(C.CARD, dp(16).toFloat())
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); lp.topMargin = dp(8)
        row.layoutParams = lp
        val check = TextView(this); check.text = if (t.done) "☑" else "⬜"; check.textSize = 22f
        check.setTextColor(if (t.done) C.PRIMARY else C.MUTED); check.layoutParams = LinearLayout.LayoutParams(dp(36), ViewGroup.LayoutParams.WRAP_CONTENT)
        check.setOnClickListener { onToggle() }
        val info = LinearLayout(this); info.orientation = LinearLayout.VERTICAL
        info.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val title = TextView(this); title.text = t.title; title.textSize = 16f; title.setTextColor(C.TEXT)
        if (t.done) title.paintFlags = title.paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
        info.addView(title)
        val sub = (if (t.timeMinutes != null) String.format("%02d:%02d", t.timeMinutes!! / 60, t.timeMinutes!! % 60) + "  •  " else "") +
            (if (t.repeatDaily) "متكررة" else "اليوم")
        info.addView(tv(sub, 12f, C.MUTED))
        val dot = TextView(this); dot.text = "●"; dot.setTextColor(prColor); dot.textSize = 14f
        row.addView(check); row.addView(info); row.addView(dot)
        return row
    }

    private fun toggleTask(t: Task) {
        val all = store.tasksList(); val idx = all.indexOfFirst { it.id == t.id }
        if (idx >= 0) { all[idx].done = !all[idx].done; store.saveTasks(all) }
        current?.invoke()
    }

    private fun showTasks() {
        current = { showTasks() }
        val col = page(2, { showHome() }, "مهامي")
        col.addView(btn("＋ إضافة مهمة") { addTaskDialog() })
        val tasks = store.tasksForToday().sortedByDescending { it.priority }
        if (tasks.isEmpty()) col.addView(tv("لا توجد مهام اليوم.", 14f, C.MUTED, false, true))
        for (t in tasks) col.addView(taskRow(t) { toggleTask(t) })
    }

    private fun addTaskDialog() {
        val box = LinearLayout(this); box.orientation = LinearLayout.VERTICAL; box.setPadding(dp(20), dp(10), dp(20), 0)
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val title = EditText(this); title.hint = "اسم المهمة"
        var priority = 1; var minutes: Int? = null; var repeat = false
        box.addView(title)
        val prRow = LinearLayout(this); prRow.orientation = LinearLayout.HORIZONTAL
        val plp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); plp.topMargin = dp(10)
        prRow.layoutParams = plp
        val labels = listOf("منخفضة", "متوسطة", "عالية")
        lateinit var refreshChips: () -> Unit
        refreshChips = {
            prRow.removeAllViews()
            labels.forEachIndexed { i, l -> prRow.addView(chip(l, i == priority) { priority = i; refreshChips() }) }
        }
        refreshChips(); box.addView(prRow)
        val timeBtn = smallBtn("⏰ تحديد وقت (اختياري)") {}
        timeBtn.setOnClickListener {
            val cal = java.util.Calendar.getInstance()
            TimePickerDialog(this, { _, h, m -> minutes = h * 60 + m; timeBtn.text = String.format("⏰ %02d:%02d", h, m) },
                cal.get(java.util.Calendar.HOUR_OF_DAY), cal.get(java.util.Calendar.MINUTE), true).show()
        }
        box.addView(timeBtn)
        val repRow = LinearLayout(this); repRow.orientation = LinearLayout.HORIZONTAL; repRow.gravity = Gravity.CENTER_VERTICAL
        val cb = android.widget.CheckBox(this); cb.text = "مهمة متكررة يوميًا"
        cb.setOnCheckedChangeListener { _, v -> repeat = v }
        repRow.addView(cb); box.addView(repRow)

        AlertDialog.Builder(this).setTitle("إضافة مهمة").setView(box)
            .setPositiveButton("إضافة") { _, _ ->
                val t = title.text.toString().trim()
                if (t.isNotEmpty()) {
                    val all = store.tasksList()
                    val task = Task(UUID.randomUUID().toString(), t, priority, minutes, repeat, store.today(), false)
                    all.add(task); store.saveTasks(all)
                    if (minutes != null) Scheduler.scheduleTask(this, task.id, minutes!!, t)
                }
                showTasks()
            }.setNegativeButton("إلغاء", null).show()
    }

    // ---------------- العادات ----------------
    private fun showHabits() {
        current = { showHabits() }
        val col = page(3, { showHome() }, "عاداتي")
        col.addView(btn("＋ إضافة عادة") { addHabitDialog() })
        val habits = store.habits()
        if (habits.isEmpty()) col.addView(tv("لا توجد عادات بعد.", 14f, C.MUTED, false, true))
        for (h in habits) {
            val c = card()
            val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
            row.addView(tv("${h.emoji}  ${h.name}", 17f, C.TEXT, true).also { it.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
            row.addView(smallBtn("حذف") {
                AlertDialog.Builder(this).setMessage("حذف عادة «${h.name}»؟")
                    .setPositiveButton("حذف") { _, _ -> val l = store.habits(); l.removeAll { it.id == h.id }; store.saveHabits(l); showHabits() }
                    .setNegativeButton("إلغاء", null).show()
            })
            c.addView(row)
            val days = LinearLayout(this); days.orientation = LinearLayout.HORIZONTAL
            val dlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); dlp.topMargin = dp(10)
            days.layoutParams = dlp
            for (off in 6 downTo 0) {
                val d = store.dayStr(-off); val done = store.habitDone(h.id, d)
                val cell = TextView(this); cell.text = if (done) "✓" else ""; cell.setTextColor(C.ON_PRIMARY); cell.gravity = Gravity.CENTER
                cell.background = rounded(if (done) C.PRIMARY else C.SOFT, dp(10).toFloat())
                val clp = LinearLayout.LayoutParams(0, dp(36), 1f); clp.marginStart = dp(3); clp.marginEnd = dp(3)
                cell.layoutParams = clp
                if (off == 0) cell.setOnClickListener { store.setHabitDone(h.id, d, !done); showHabits() }
                days.addView(cell)
            }
            c.addView(days)
            col.addView(c)
        }
    }

    private fun addHabitDialog() {
        val box = LinearLayout(this); box.orientation = LinearLayout.VERTICAL; box.setPadding(dp(20), dp(10), dp(20), 0)
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val name = EditText(this); name.hint = "اسم العادة (مثل: شرب الماء)"
        val emoji = EditText(this); emoji.hint = "رمز تعبيري (اختياري) مثل 💧"
        box.addView(name); box.addView(emoji)
        AlertDialog.Builder(this).setTitle("إضافة عادة").setView(box)
            .setPositiveButton("إضافة") { _, _ ->
                val n = name.text.toString().trim()
                if (n.isNotEmpty()) {
                    val l = store.habits(); l.add(Habit(UUID.randomUUID().toString(), n, emoji.text.toString().ifEmpty { "🌱" })); store.saveHabits(l)
                }
                showHabits()
            }.setNegativeButton("إلغاء", null).show()
    }

    // ---------------- مراجعة اليوم ----------------
    private fun showReview() {
        current = { showReview() }
        val col = page(-1, { showHome() }, "مراجعة اليوم")
        val existing = store.review(store.today())
        var mood = existing?.mood ?: 3; var stars = existing?.stars ?: 3
        val moodRow = LinearLayout(this); moodRow.orientation = LinearLayout.HORIZONTAL
        lateinit var refreshMood: () -> Unit
        refreshMood = {
            moodRow.removeAllViews()
            for (m in 1..5) {
                val e = TextView(this); e.text = moodEmoji(m); e.textSize = 26f; e.gravity = Gravity.CENTER
                e.alpha = if (m == mood) 1f else 0.4f
                e.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                e.setOnClickListener { mood = m; refreshMood() }
                moodRow.addView(e)
            }
        }
        col.addView(tv("مزاجك اليوم", 15f, C.MUTED)); refreshMood(); col.addView(moodRow)

        fun field(hint: String, value: String): EditText {
            val e = EditText(this); e.hint = hint; e.setText(value); e.minLines = 2
            e.setPadding(dp(14), dp(12), dp(14), dp(12)); e.background = rounded(C.CARD, dp(14).toFloat())
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); lp.topMargin = dp(10)
            e.layoutParams = lp; col.addView(tv(hint, 14f, C.MUTED)); col.addView(e); return e
        }
        val ach = field("ماذا أنجزت اليوم؟", existing?.achieved ?: "")
        val good = field("ما الشيء الجميل الذي حصل؟", existing?.good ?: "")
        val bad = field("ما الشيء الذي لم يعجبك؟", existing?.bad ?: "")
        val avoid = field("ما الخطأ الذي تريد ألا تكرره؟", existing?.avoidRepeat ?: "")
        val tom = field("ماذا تريد أن تفعل غدًا؟", existing?.tomorrow ?: "")

        val starRow = LinearLayout(this); starRow.orientation = LinearLayout.HORIZONTAL
        val srlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); srlp.topMargin = dp(10)
        starRow.layoutParams = srlp
        lateinit var refreshStars: () -> Unit
        refreshStars = {
            starRow.removeAllViews()
            for (s in 1..5) {
                val e = TextView(this); e.text = if (s <= stars) "★" else "☆"; e.textSize = 30f; e.setTextColor(C.GOLD); e.gravity = Gravity.CENTER
                e.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                e.setOnClickListener { stars = s; refreshStars() }
                starRow.addView(e)
            }
        }
        col.addView(tv("قيّم يومك", 14f, C.MUTED)); refreshStars(); col.addView(starRow)

        col.addView(btn("حفظ") {
            store.saveReview(Review(store.today(), mood, ach.text.toString(), good.text.toString(), bad.text.toString(), avoid.text.toString(), tom.text.toString(), stars))
            showHome()
        })
    }

    // ---------------- الإعدادات ----------------
    private fun showSettings() {
        current = { showSettings() }
        val col = page(4, { showHome() }, "الإعدادات")
        col.addView(tv("المظهر", 16f, C.PRIMARY_DARK, true))
        val themeRow = LinearLayout(this); themeRow.orientation = LinearLayout.HORIZONTAL
        val trlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); trlp.topMargin = dp(8)
        themeRow.layoutParams = trlp
        C.NAMES.forEachIndexed { i, n -> themeRow.addView(chip(n, i == store.theme) { store.theme = i; C.set(i); styleBars(); showSettings() }) }
        col.addView(themeRow)

        col.addView(tv("الحماية", 16f, C.PRIMARY_DARK, true))
        col.addView(btn(if (store.pin.isEmpty()) "تعيين رمز قفل" else "تغيير رمز القفل", C.CARD, C.PRIMARY_DARK) { setPinDialog() })
        val bioAvail = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
        if (bioAvail) {
            val sw = android.widget.Switch(this); sw.text = "استخدام البصمة لفتح اليوميات"; sw.isChecked = store.biometricOn
            sw.setTextColor(C.TEXT); sw.setOnCheckedChangeListener { _, v -> store.biometricOn = v }
            val c = card(); c.addView(sw); col.addView(c)
        }
        col.addView(tv("هذا التطبيق يعمل بدون إنترنت، وكل بياناتك محفوظة على جهازك فقط.", 13f, C.MUTED))
    }

    private fun setPinDialog() {
        val input = EditText(this); input.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIANT_PASSWORD
        input.hint = "رمز من 4 أرقام"
        AlertDialog.Builder(this).setTitle("رمز القفل").setView(input)
            .setPositiveButton("حفظ") { _, _ -> val v = input.text.toString(); if (v.length >= 4) store.pin = v; showSettings() }
            .setNegativeButton("إلغاء", null)
            .setNeutralButton("إزالة القفل") { _, _ -> store.pin = ""; store.biometricOn = false; showSettings() }
            .show()
    }
}
