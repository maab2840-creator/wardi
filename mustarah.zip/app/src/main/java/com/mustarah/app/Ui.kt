package com.mustarah.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

object C {
    var idx = 0
    var BG = 0; var CARD = 0; var PRIMARY = 0; var PRIMARY_DARK = 0; var ON_PRIMARY = 0
    var TEXT = 0; var MUTED = 0; var SOFT = 0; var BORDER = 0; var WARN = 0; var GOLD = 0

    val NAMES = listOf("طبيعة", "ليل", "هادئ", "ناعم", "داكن")

    fun set(i: Int) {
        idx = i
        when (i) {
            1 -> { BG="#101826".c(); CARD="#1A2436".c(); PRIMARY="#C9A24B".c(); PRIMARY_DARK="#E6C06A".c(); ON_PRIMARY="#14202E".c(); TEXT="#EDEFF3".c(); MUTED="#9AA6B8".c(); SOFT="#23304A".c(); BORDER="#2B3A56".c(); WARN="#FF8A80".c(); GOLD="#C9A24B".c() }
            2 -> { BG="#EEF3F7".c(); CARD="#FFFFFF".c(); PRIMARY="#4F7FA6".c(); PRIMARY_DARK="#3C647F".c(); ON_PRIMARY="#FFFFFF".c(); TEXT="#2B3844".c(); MUTED="#73838F".c(); SOFT="#DCEAF4".c(); BORDER="#CFE0ED".c(); WARN="#B3402F".c(); GOLD="#C9A24B".c() }
            3 -> { BG="#F7EEF2".c(); CARD="#FFFFFF".c(); PRIMARY="#B06A85".c(); PRIMARY_DARK="#8A4F68".c(); ON_PRIMARY="#FFFFFF".c(); TEXT="#3A2B32".c(); MUTED="#8C7680".c(); SOFT="#F1DEE6".c(); BORDER="#E6CCD6".c(); WARN="#B3402F".c(); GOLD="#C9A24B".c() }
            4 -> { BG="#15181A".c(); CARD="#1F2326".c(); PRIMARY="#7FAE8A".c(); PRIMARY_DARK="#9BC4A5".c(); ON_PRIMARY="#10140F".c(); TEXT="#ECEFEC".c(); MUTED="#97A099".c(); SOFT="#262B28".c(); BORDER="#2E3431".c(); WARN="#FF8A80".c(); GOLD="#C9A24B".c() }
            else -> { BG="#F3F1E9".c(); CARD="#FFFFFF".c(); PRIMARY="#5B7A55".c(); PRIMARY_DARK="#44603F".c(); ON_PRIMARY="#FFFFFF".c(); TEXT="#2E2B22".c(); MUTED="#7A7563".c(); SOFT="#E6E6D6".c(); BORDER="#DADACB".c(); WARN="#B3402F".c(); GOLD="#C9A24B".c() }
        }
    }
    private fun String.c() = Color.parseColor(this)
    init { set(0) }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun rounded(color: Int, r: Float): GradientDrawable { val g = GradientDrawable(); g.setColor(color); g.cornerRadius = r; return g }
fun outlined(color: Int, stroke: Int, r: Float, w: Int): GradientDrawable { val g = rounded(color, r); g.setStroke(w, stroke); return g }

fun Context.tv(text: String, size: Float = 16f, color: Int = C.TEXT, bold: Boolean = false, center: Boolean = false): TextView {
    val t = TextView(this); t.text = text; t.textSize = size; t.setTextColor(color)
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    if (center) t.gravity = Gravity.CENTER
    val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    lp.topMargin = dp(6); t.layoutParams = lp
    return t
}

fun Context.btn(text: String, bg: Int = C.PRIMARY, fg: Int = C.ON_PRIMARY, onClick: () -> Unit): TextView {
    val t = TextView(this); t.text = text; t.textSize = 17f; t.setTextColor(fg); t.gravity = Gravity.CENTER
    t.setTypeface(t.typeface, Typeface.BOLD); t.setPadding(dp(16), dp(14), dp(16), dp(14))
    t.background = rounded(bg, dp(24).toFloat())
    val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    lp.topMargin = dp(10); t.layoutParams = lp; t.setOnClickListener { onClick() }
    return t
}

fun Context.card(): LinearLayout {
    val c = LinearLayout(this); c.orientation = LinearLayout.VERTICAL
    c.setPadding(dp(16), dp(14), dp(16), dp(14))
    val bg = rounded(C.CARD, dp(20).toFloat()); bg.setStroke(dp(1), C.BORDER); c.background = bg
    val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    lp.topMargin = dp(12); c.layoutParams = lp
    return c
}
